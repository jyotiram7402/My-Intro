'use client';

import { useEffect } from 'react';
import { getSocket } from '@/lib/socket';
import { useStore } from '@/lib/store';

/**
 * Subscribes to the gateway's Socket.IO stream and pipes events into
 * the global store. Mount this once in the dashboard layout.
 */
export function useGatewayStream() {
  const setShield = useStore((s) => s.setShield);
  const setMetrics = useStore((s) => s.setMetrics);
  const setCpu = useStore((s) => s.setCpu);
  const pushEvent = useStore((s) => s.pushEvent);
  const pushAlert = useStore((s) => s.pushAlert);
  const setConnected = useStore((s) => s.setConnected);

  useEffect(() => {
    const socket = getSocket();

    const onConnect = () => setConnected(true);
    const onDisconnect = () => setConnected(false);

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);

    socket.on('hello', (snap: any) => {
      if (snap.shield) setShield(snap.shield);
      if (snap.metrics) setMetrics(snap.metrics);
      if (snap.cpu) setCpu(snap.cpu);
    });
    socket.on('shield', setShield);
    socket.on('metrics', setMetrics);
    socket.on('cpu', setCpu);
    socket.on('traffic', pushEvent);
    socket.on('alert', pushAlert);

    if (socket.connected) onConnect();

    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('hello');
      socket.off('shield');
      socket.off('metrics');
      socket.off('cpu');
      socket.off('traffic');
      socket.off('alert');
    };
  }, [setShield, setMetrics, setCpu, pushEvent, pushAlert, setConnected]);
}
