'use client';

import { io, type Socket } from 'socket.io-client';

let socket: Socket | null = null;

export function getSocket(): Socket {
  if (typeof window === 'undefined') throw new Error('socket() called on the server');
  if (socket && socket.connected) return socket;
  const url = process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:5000';
  socket = io(url, {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionDelayMax: 4000,
    withCredentials: true,
  });
  return socket;
}
