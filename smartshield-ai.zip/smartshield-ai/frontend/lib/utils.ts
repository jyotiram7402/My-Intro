import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(n: number, fractionDigits = 0) {
  if (n === undefined || n === null || Number.isNaN(n)) return '–';
  return n.toLocaleString('en-US', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  });
}

export function formatPercent(n: number, digits = 0) {
  if (Number.isNaN(n)) return '–';
  return `${(n * 100).toFixed(digits)}%`;
}

export function formatTime(ts: number) {
  return new Date(ts).toLocaleTimeString('en-GB', { hour12: false });
}

export function classifyScore(score: number): 'human' | 'suspicious' | 'bot' {
  if (score >= 0.7) return 'bot';
  if (score >= 0.4) return 'suspicious';
  return 'human';
}

export function scoreColor(score: number): string {
  if (score >= 0.85) return 'text-cyber-red';
  if (score >= 0.7) return 'text-cyber-amber';
  if (score >= 0.4) return 'text-cyber-violet';
  return 'text-cyber-cyan';
}
