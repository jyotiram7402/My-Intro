/**
 * Thin axios wrapper around the SmartShield gateway.
 *
 * The gateway URL comes from NEXT_PUBLIC_GATEWAY_URL.
 */
import axios from 'axios';

const baseURL = process.env.NEXT_PUBLIC_GATEWAY_URL || 'http://localhost:5000';

export const api = axios.create({
  baseURL,
  timeout: 8_000,
  withCredentials: true,
});

export const adminApi = {
  state: () => api.get('/api/admin/state').then((r) => r.data),
  patch: (body: any) => api.patch('/api/admin/state', body).then((r) => r.data),
};

export const metricsApi = {
  summary: () => api.get('/api/metrics/summary').then((r) => r.data),
  timeseries: (bucket = 1000, window = 120_000) =>
    api.get('/api/metrics/timeseries', { params: { bucket, window } }).then((r) => r.data),
  recent: (n = 100) => api.get('/api/metrics/recent', { params: { n } }).then((r) => r.data),
  history: (limit = 200) =>
    api.get('/api/metrics/history', { params: { limit } }).then((r) => r.data),
  countries: () => api.get('/api/metrics/countries').then((r) => r.data),
};

export const simulatorApi = {
  start: (body: any) => api.post('/api/shield/simulate/start', body).then((r) => r.data),
  stop: () => api.post('/api/shield/simulate/stop').then((r) => r.data),
  status: () => api.get('/api/shield/simulate/status').then((r) => r.data),
};
