'use client';

/**
 * Global Zustand store. Holds the streaming dashboard state:
 *   - shield config
 *   - latest metrics + cpu sample
 *   - live traffic ring buffer
 *   - alert ring buffer
 */

import { create } from 'zustand';

export type TrafficEvent = {
  requestId: string;
  ts: number;
  ip: string;
  country?: { code: string; name: string; lat: number; lng: number };
  method: string;
  path: string;
  ua: string;
  score: number;
  classification: string;
  action: 'allow' | 'block' | 'challenge';
  modelSource?: string;
  modelConfidence?: number;
  features?: Record<string, any>;
  bypass?: string | null;
};

export type Alert = {
  level: 'info' | 'warn' | 'error';
  title: string;
  detail?: string;
  ts: number;
};

export type CpuSample = { ts: number; cpu: number; rssMb: number; heapMb: number; load1: number };

export type Metrics = {
  windowMs: number;
  total: number;
  rps: number;
  allowed: number;
  blocked: number;
  challenged: number;
  human: number;
  bot: number;
  suspicious: number;
  avgScore: number;
  byCountry: Record<string, number>;
  blockRate: number;
  botRate: number;
};

export type ShieldState = {
  enabled: boolean;
  blockThreshold: number;
  challengeThreshold: number;
  challenge?: { pendingChallenges: number; activeTokens: number };
};

type Store = {
  shield: ShieldState;
  metrics: Metrics | null;
  cpu: CpuSample | null;
  cpuSeries: CpuSample[];
  events: TrafficEvent[];
  alerts: Alert[];
  socketConnected: boolean;
  setShield: (s: ShieldState) => void;
  setMetrics: (m: Metrics) => void;
  setCpu: (c: CpuSample) => void;
  pushEvent: (e: TrafficEvent) => void;
  pushAlert: (a: Alert) => void;
  setConnected: (b: boolean) => void;
};

const MAX_EVENTS = 250;
const MAX_ALERTS = 50;
const MAX_CPU_SAMPLES = 240;

export const useStore = create<Store>((set) => ({
  shield: { enabled: true, blockThreshold: 0.85, challengeThreshold: 0.55 },
  metrics: null,
  cpu: null,
  cpuSeries: [],
  events: [],
  alerts: [],
  socketConnected: false,
  setShield: (s) => set({ shield: s }),
  setMetrics: (m) => set({ metrics: m }),
  setCpu: (c) =>
    set((state) => ({
      cpu: c,
      cpuSeries: [...state.cpuSeries.slice(-(MAX_CPU_SAMPLES - 1)), c],
    })),
  pushEvent: (e) => set((state) => ({ events: [e, ...state.events].slice(0, MAX_EVENTS) })),
  pushAlert: (a) => set((state) => ({ alerts: [a, ...state.alerts].slice(0, MAX_ALERTS) })),
  setConnected: (b) => set({ socketConnected: b }),
}));
