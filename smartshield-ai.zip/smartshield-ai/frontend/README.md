# SmartShield Dashboard (Frontend)

Modern, neon-cyber Next.js dashboard for the SmartShield AI gateway.

## Features

- Live RPS / CPU / risk-score charts (Recharts)
- AI risk scoring panels with explainability
- Country-wise attack distribution
- Real-time alert feed + suspicious-IP table
- Embedded attack simulator controls
- Dark / light theme (default dark)
- Glassmorphism + neon aesthetic
- Mobile responsive

## Run

```bash
cp .env.example .env.local
npm install
npm run dev    # http://localhost:3000
```

The dashboard expects the gateway at `NEXT_PUBLIC_GATEWAY_URL` (default
`http://localhost:5000`) and the Socket.IO stream at `NEXT_PUBLIC_SOCKET_URL`.

## Pages

| Path | Purpose |
|------|---------|
| `/` | Operations overview (default landing page) |
| `/analytics` | Time-series analytics |
| `/threats` | Country distribution + suspect IPs |
| `/logs` | Live request log |
| `/simulator` | Run controlled attacks |
| `/settings` | Shield toggle + thresholds |

## Tech

- Next.js 14 (App Router) + React 18
- Tailwind CSS + ShadCN UI primitives
- Framer Motion animations
- Recharts for streaming charts
- Zustand global store
- Socket.IO client for live events
