'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrafficChart } from '@/components/charts/traffic-chart';
import { CpuChart } from '@/components/charts/cpu-chart';
import { ScoreChart } from '@/components/charts/score-chart';
import { ClassificationPie } from '@/components/charts/classification-pie';
import { metricsApi } from '@/lib/api';

export default function AnalyticsPage() {
  const [history, setHistory] = useState<any[]>([]);

  useEffect(() => {
    metricsApi.history(200).then(setHistory).catch(() => setHistory([]));
  }, []);

  const blocked = history.filter((e) => e.action === 'block').length;
  const challenged = history.filter((e) => e.action === 'challenge').length;
  const allowed = history.filter((e) => e.action === 'allow').length;

  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h1 className="text-2xl font-bold">Analytics</h1>
        <p className="text-sm text-muted-foreground">
          Time-series view of traffic + AI scoring across the rolling window.
        </p>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat label="Total persisted" value={history.length} />
        <Stat label="Allowed" value={allowed} color="text-cyber-lime" />
        <Stat label="Challenged" value={challenged} color="text-cyber-amber" />
        <Stat label="Blocked" value={blocked} color="text-cyber-red" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Traffic actions</CardTitle>
          </CardHeader>
          <CardContent>
            <TrafficChart />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>CPU utilisation</CardTitle>
          </CardHeader>
          <CardContent>
            <CpuChart />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>AI risk score</CardTitle>
          </CardHeader>
          <CardContent>
            <ScoreChart />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Classification</CardTitle>
          </CardHeader>
          <CardContent>
            <ClassificationPie />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color?: string }) {
  return (
    <Card>
      <CardContent className="p-5">
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className={`text-3xl font-bold mt-2 ${color || ''}`}>{value}</p>
      </CardContent>
    </Card>
  );
}
