'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { simulatorApi } from '@/lib/api';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrafficChart } from '@/components/charts/traffic-chart';
import { CpuChart } from '@/components/charts/cpu-chart';
import { ThreatIntelCards } from '@/components/dashboard/threat-intel-cards';
import { ShieldToggle } from '@/components/dashboard/shield-toggle';
import { motion } from 'framer-motion';
import { Play, Square, Bot, Zap, Users } from 'lucide-react';

export default function SimulatorPage() {
  const [busy, setBusy] = useState(false);
  const [active, setActive] = useState<any>(null);
  const [mode, setMode] = useState<'bot' | 'human' | 'flood' | 'mixed'>('bot');
  const [concurrency, setConcurrency] = useState(25);
  const [duration, setDuration] = useState(60);

  useEffect(() => {
    const t = setInterval(async () => {
      try {
        const s = await simulatorApi.status();
        setActive(s.attack);
      } catch {
        setActive(null);
      }
    }, 1500);
    return () => clearInterval(t);
  }, []);

  const start = async () => {
    setBusy(true);
    try {
      await simulatorApi.start({ mode, concurrency, durationSec: duration });
    } finally {
      setBusy(false);
    }
  };
  const stop = async () => {
    setBusy(true);
    try {
      await simulatorApi.stop();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h1 className="text-2xl font-bold">Attack simulator</h1>
        <p className="text-sm text-muted-foreground">
          Run controlled bot / human / flood traffic against the gateway. Toggle SmartShield
          and watch the impact in real time.
        </p>
      </header>

      <ThreatIntelCards />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Launch attack</CardTitle>
            <CardDescription>
              Server-side simulator — runs from inside the gateway against `/proxy/`.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <Tabs value={mode} onValueChange={(v) => setMode(v as any)}>
              <TabsList className="grid grid-cols-4">
                <TabsTrigger value="bot">
                  <Bot className="h-3 w-3 mr-1" /> Bots
                </TabsTrigger>
                <TabsTrigger value="human">
                  <Users className="h-3 w-3 mr-1" /> Humans
                </TabsTrigger>
                <TabsTrigger value="flood">
                  <Zap className="h-3 w-3 mr-1" /> Flood
                </TabsTrigger>
                <TabsTrigger value="mixed">Mixed</TabsTrigger>
              </TabsList>
              <TabsContent value="bot" className="text-xs text-muted-foreground">
                Aggressive scrapers + credential stuffers with naked user agents and missing
                headers — exactly what the AI engine should catch.
              </TabsContent>
              <TabsContent value="human" className="text-xs text-muted-foreground">
                Realistic browser-like requests with full headers and cookies. Should mostly
                pass through.
              </TabsContent>
              <TabsContent value="flood" className="text-xs text-muted-foreground">
                Pure volumetric flood designed to spike CPU on the dummy site.
              </TabsContent>
              <TabsContent value="mixed" className="text-xs text-muted-foreground">
                60% bot / 30% human / 10% flood — useful for measuring false-positive rate.
              </TabsContent>
            </Tabs>

            <div className="grid grid-cols-2 gap-4">
              <NumberControl
                label="Concurrency"
                value={concurrency}
                onChange={setConcurrency}
                min={1}
                max={100}
              />
              <NumberControl
                label="Duration (sec)"
                value={duration}
                onChange={setDuration}
                min={5}
                max={300}
              />
            </div>

            <div className="flex items-center gap-3">
              <Button variant="neon" onClick={start} disabled={busy || !!active}>
                <Play className="h-4 w-4" /> Start attack
              </Button>
              <Button variant="destructive" onClick={stop} disabled={busy || !active}>
                <Square className="h-4 w-4" /> Stop
              </Button>
              {active && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center gap-2"
                >
                  <Badge variant="warning" className="animate-glow">
                    LIVE — {active.mode} × {active.concurrency}
                  </Badge>
                </motion.div>
              )}
            </div>
          </CardContent>
        </Card>

        <ShieldToggle />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Traffic actions</CardTitle>
          </CardHeader>
          <CardContent>
            <TrafficChart />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>System CPU</CardTitle>
          </CardHeader>
          <CardContent>
            <CpuChart />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function NumberControl({
  label,
  value,
  onChange,
  min,
  max,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
}) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <div className="mt-1 flex items-center gap-2">
        <input
          type="range"
          min={min}
          max={max}
          value={value}
          onChange={(e) => onChange(Number(e.target.value))}
          className="flex-1 accent-primary"
        />
        <span className="w-10 text-right text-sm font-mono">{value}</span>
      </div>
    </label>
  );
}
