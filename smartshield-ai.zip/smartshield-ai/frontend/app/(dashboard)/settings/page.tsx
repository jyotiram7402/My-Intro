'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { adminApi } from '@/lib/api';
import { useStore } from '@/lib/store';

export default function SettingsPage() {
  const shield = useStore((s) => s.shield);
  const setShield = useStore((s) => s.setShield);
  const [block, setBlock] = useState(shield.blockThreshold);
  const [challenge, setChallenge] = useState(shield.challengeThreshold);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setBlock(shield.blockThreshold);
    setChallenge(shield.challengeThreshold);
  }, [shield.blockThreshold, shield.challengeThreshold]);

  const save = async () => {
    setBusy(true);
    try {
      const s = await adminApi.patch({
        blockThreshold: block,
        challengeThreshold: challenge,
      });
      setShield(s);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <header>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm text-muted-foreground">
          Tune shield thresholds and toggle protection.
        </p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Shield enabled</CardTitle>
          <CardDescription>Master switch for the SmartShield pipeline.</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-between">
          <span className="text-sm">{shield.enabled ? 'Enabled' : 'Disabled'}</span>
          <Switch
            checked={shield.enabled}
            onCheckedChange={async (v) => {
              const s = await adminApi.patch({ enabled: v });
              setShield(s);
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Risk thresholds</CardTitle>
          <CardDescription>
            Adjust the score boundaries that trigger a JS challenge or an outright block.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Slider
            label={`Block threshold — ${(block * 100).toFixed(0)}%`}
            value={block}
            onChange={setBlock}
            color="bg-cyber-red"
          />
          <Slider
            label={`Challenge threshold — ${(challenge * 100).toFixed(0)}%`}
            value={challenge}
            onChange={setChallenge}
            color="bg-cyber-amber"
          />
          <div className="flex justify-end">
            <Button onClick={save} disabled={busy}>
              Save
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>About</CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-2 text-muted-foreground">
          <p>SmartShield AI &mdash; M.Tech research project, 2026.</p>
          <p>
            Adaptive bot mitigation using LSTM, Random Forest, Isolation Forest, and an
            Autoencoder ensemble. See <code>docs/RESEARCH.md</code> for the full write-up.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function Slider({
  label,
  value,
  onChange,
  color,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  color: string;
}) {
  return (
    <label className="block">
      <span className="text-xs text-muted-foreground">{label}</span>
      <input
        type="range"
        min={0}
        max={1}
        step={0.01}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className={`mt-2 w-full accent-primary`}
      />
      <div className={`mt-1 h-1 rounded-full ${color}`} style={{ width: `${value * 100}%` }} />
    </label>
  );
}
