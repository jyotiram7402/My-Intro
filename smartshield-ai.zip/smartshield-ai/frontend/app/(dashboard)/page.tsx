'use client';

import { useStore } from '@/lib/store';
import { StatCard } from '@/components/dashboard/stat-card';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrafficChart } from '@/components/charts/traffic-chart';
import { CpuChart } from '@/components/charts/cpu-chart';
import { ScoreChart } from '@/components/charts/score-chart';
import { ClassificationPie } from '@/components/charts/classification-pie';
import { LiveLog } from '@/components/dashboard/live-log';
import { ThreatIntelCards } from '@/components/dashboard/threat-intel-cards';
import { ShieldToggle } from '@/components/dashboard/shield-toggle';
import { WorldMap } from '@/components/dashboard/world-map';
import { AlertFeed } from '@/components/dashboard/alert-feed';
import { Activity, ShieldCheck, AlertTriangle, Zap } from 'lucide-react';

export default function OverviewPage() {
  const m = useStore((s) => s.metrics);
  const cpu = useStore((s) => s.cpu);

  const rps = m ? m.rps.toFixed(1) : '0.0';
  const blocked = m?.blocked ?? 0;
  const challenged = m?.challenged ?? 0;
  const total = m?.total ?? 0;

  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Operations overview</h1>
        <p className="text-sm text-muted-foreground">
          Live adaptive bot mitigation dashboard. Streaming over WebSocket.
        </p>
      </header>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Requests / sec"
          value={rps}
          hint={`${total} in last minute`}
          icon={Activity}
          accent="primary"
        />
        <StatCard
          label="Blocked"
          value={blocked}
          hint="last 60s"
          icon={ShieldCheck}
          accent="red"
        />
        <StatCard
          label="Challenged"
          value={challenged}
          hint="JS PoW issued"
          icon={AlertTriangle}
          accent="amber"
        />
        <StatCard
          label="CPU load"
          value={`${(cpu?.cpu ?? 0).toFixed(1)}%`}
          hint={cpu ? `${cpu.rssMb.toFixed(0)} MB rss` : ''}
          icon={Zap}
          accent="violet"
        />
      </div>

      <ThreatIntelCards />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <ShieldToggle />
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Traffic timeline (allow / challenge / block)</CardTitle>
          </CardHeader>
          <CardContent>
            <TrafficChart />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>System CPU utilisation</CardTitle>
          </CardHeader>
          <CardContent>
            <CpuChart />
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>AI risk score (per request)</CardTitle>
          </CardHeader>
          <CardContent>
            <ScoreChart />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Classification mix (60s)</CardTitle>
          </CardHeader>
          <CardContent>
            <ClassificationPie />
          </CardContent>
        </Card>
        <WorldMap />
        <AlertFeed />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Live request log</CardTitle>
        </CardHeader>
        <CardContent>
          <LiveLog />
        </CardContent>
      </Card>
    </div>
  );
}
