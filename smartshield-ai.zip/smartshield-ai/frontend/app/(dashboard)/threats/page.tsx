'use client';

import { useMemo } from 'react';
import { useStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { WorldMap } from '@/components/dashboard/world-map';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function ThreatsPage() {
  const events = useStore((s) => s.events);

  const suspectIps = useMemo(() => {
    const map = new Map<string, { ip: string; total: number; blocked: number; avgScore: number; country?: string }>();
    for (const e of events) {
      const v = map.get(e.ip) || { ip: e.ip, total: 0, blocked: 0, avgScore: 0, country: e.country?.code };
      v.total += 1;
      if (e.action === 'block') v.blocked += 1;
      v.avgScore = (v.avgScore * (v.total - 1) + (e.score || 0)) / v.total;
      v.country = e.country?.code;
      map.set(e.ip, v);
    }
    return [...map.values()].sort((a, b) => b.avgScore - a.avgScore).slice(0, 30);
  }, [events]);

  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h1 className="text-2xl font-bold">Threat intelligence</h1>
        <p className="text-sm text-muted-foreground">
          Geographic distribution of attack origins and the highest-risk client IPs.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <WorldMap />
        <Card>
          <CardHeader>
            <CardTitle>Suspicious IPs</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[420px] pr-2">
              <ul className="space-y-2 font-mono text-xs">
                {suspectIps.length === 0 && (
                  <li className="text-center text-muted-foreground py-6">
                    No suspicious activity yet.
                  </li>
                )}
                {suspectIps.map((ip) => (
                  <li
                    key={ip.ip}
                    className="flex items-center gap-3 px-2 py-2 rounded-md hover:bg-muted/40"
                  >
                    <span className="w-32 truncate">{ip.ip}</span>
                    {ip.country && (
                      <span className="text-muted-foreground text-[10px]">{ip.country}</span>
                    )}
                    <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full ${
                          ip.avgScore > 0.7
                            ? 'bg-cyber-red'
                            : ip.avgScore > 0.4
                            ? 'bg-cyber-amber'
                            : 'bg-primary'
                        }`}
                        style={{ width: `${ip.avgScore * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground w-12 text-right">
                      {(ip.avgScore * 100).toFixed(0)}%
                    </span>
                    <Badge variant={ip.blocked > 0 ? 'destructive' : 'secondary'}>
                      {ip.blocked}/{ip.total}
                    </Badge>
                  </li>
                ))}
              </ul>
            </ScrollArea>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
