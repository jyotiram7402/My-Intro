'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LiveLog } from '@/components/dashboard/live-log';

export default function LogsPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      <header>
        <h1 className="text-2xl font-bold">Live request log</h1>
        <p className="text-sm text-muted-foreground">
          Streaming feed of every request processed by the gateway.
        </p>
      </header>
      <Card>
        <CardHeader>
          <CardTitle>Last 250 events</CardTitle>
        </CardHeader>
        <CardContent>
          <LiveLog limit={250} />
        </CardContent>
      </Card>
    </div>
  );
}
