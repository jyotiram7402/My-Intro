'use client';

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useMemo } from 'react';
import { useStore } from '@/lib/store';
import { formatTime } from '@/lib/utils';

export function TrafficChart() {
  const events = useStore((s) => s.events);

  // Bucket events into 1-second bins for the last 60 seconds.
  const data = useMemo(() => {
    const now = Date.now();
    const bins = new Map<number, { ts: number; allowed: number; blocked: number; challenged: number }>();
    for (let t = now - 60_000; t <= now; t += 1000) {
      const k = Math.floor(t / 1000) * 1000;
      bins.set(k, { ts: k, allowed: 0, blocked: 0, challenged: 0 });
    }
    for (const e of events) {
      const k = Math.floor(e.ts / 1000) * 1000;
      const b = bins.get(k);
      if (!b) continue;
      if (e.action === 'allow') b.allowed += 1;
      else if (e.action === 'block') b.blocked += 1;
      else if (e.action === 'challenge') b.challenged += 1;
    }
    return [...bins.values()].sort((a, b) => a.ts - b.ts);
  }, [events]);

  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={data} margin={{ left: -10, right: 10, top: 6, bottom: 0 }}>
        <defs>
          <linearGradient id="g-allowed" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.5} />
            <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="g-challenged" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#fbbf24" stopOpacity={0.45} />
            <stop offset="100%" stopColor="#fbbf24" stopOpacity={0} />
          </linearGradient>
          <linearGradient id="g-blocked" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#ef4444" stopOpacity={0.5} />
            <stop offset="100%" stopColor="#ef4444" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="2 4" vertical={false} />
        <XAxis
          dataKey="ts"
          tickFormatter={(t) => formatTime(t).slice(0, 5)}
          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
          width={28}
        />
        <Tooltip
          contentStyle={{
            background: 'hsl(var(--popover))',
            border: '1px solid hsl(var(--border))',
            borderRadius: 8,
            fontSize: 12,
          }}
          labelFormatter={(t) => formatTime(Number(t))}
        />
        <Area type="monotone" dataKey="allowed" stroke="hsl(var(--primary))" fill="url(#g-allowed)" />
        <Area type="monotone" dataKey="challenged" stroke="#fbbf24" fill="url(#g-challenged)" />
        <Area type="monotone" dataKey="blocked" stroke="#ef4444" fill="url(#g-blocked)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
