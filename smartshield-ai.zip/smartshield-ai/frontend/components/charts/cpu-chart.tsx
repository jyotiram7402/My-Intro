'use client';

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useStore } from '@/lib/store';
import { formatTime } from '@/lib/utils';

export function CpuChart() {
  const series = useStore((s) => s.cpuSeries);

  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={series} margin={{ left: -10, right: 10, top: 6, bottom: 0 }}>
        <defs>
          <linearGradient id="g-cpu" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.55} />
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="2 4" vertical={false} />
        <XAxis
          dataKey="ts"
          tickFormatter={(t) => formatTime(t).slice(0, 5)}
          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
          domain={[0, 100]}
          width={28}
        />
        <Tooltip
          contentStyle={{
            background: 'hsl(var(--popover))',
            border: '1px solid hsl(var(--border))',
            borderRadius: 8,
            fontSize: 12,
          }}
          formatter={(v: any) => `${Number(v).toFixed(1)}%`}
          labelFormatter={(t) => formatTime(Number(t))}
        />
        <Area
          type="monotone"
          dataKey="cpu"
          stroke="#8b5cf6"
          strokeWidth={2}
          fill="url(#g-cpu)"
          isAnimationActive={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
