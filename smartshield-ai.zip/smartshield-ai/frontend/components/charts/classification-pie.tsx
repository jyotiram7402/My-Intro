'use client';

import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { useStore } from '@/lib/store';

export function ClassificationPie() {
  const m = useStore((s) => s.metrics);
  const data = [
    { name: 'Human', value: m?.human ?? 0, color: '#00f0ff' },
    { name: 'Suspicious', value: m?.suspicious ?? 0, color: '#fbbf24' },
    { name: 'Bot', value: m?.bot ?? 0, color: '#ef4444' },
  ];
  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <div className="flex items-center gap-4">
      <ResponsiveContainer width="50%" height={180}>
        <PieChart>
          <Tooltip
            contentStyle={{
              background: 'hsl(var(--popover))',
              border: '1px solid hsl(var(--border))',
              borderRadius: 8,
              fontSize: 12,
            }}
          />
          <Pie
            data={data}
            innerRadius={45}
            outerRadius={70}
            paddingAngle={4}
            dataKey="value"
            stroke="none"
          >
            {data.map((d) => (
              <Cell key={d.name} fill={d.color} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
      <ul className="flex-1 space-y-2 text-sm">
        {data.map((d) => {
          const pct = total ? (d.value / total) * 100 : 0;
          return (
            <li key={d.name} className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full" style={{ background: d.color }} />
              <span className="flex-1">{d.name}</span>
              <span className="text-muted-foreground">{d.value}</span>
              <span className="text-xs text-muted-foreground w-10 text-right">
                {pct.toFixed(0)}%
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
