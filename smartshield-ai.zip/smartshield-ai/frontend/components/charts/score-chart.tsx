'use client';

import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { useStore } from '@/lib/store';
import { formatTime } from '@/lib/utils';

export function ScoreChart() {
  const events = useStore((s) => s.events);
  const data = events
    .slice()
    .reverse()
    .slice(-100)
    .map((e) => ({ ts: e.ts, score: e.score }));

  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={data} margin={{ left: -10, right: 10, top: 6, bottom: 0 }}>
        <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="2 4" vertical={false} />
        <XAxis
          dataKey="ts"
          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
          tickFormatter={(t) => formatTime(t).slice(0, 5)}
        />
        <YAxis
          tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }}
          axisLine={false}
          tickLine={false}
          domain={[0, 1]}
          width={28}
        />
        <ReferenceLine y={0.85} stroke="#ef4444" strokeDasharray="4 4" />
        <ReferenceLine y={0.55} stroke="#fbbf24" strokeDasharray="4 4" />
        <Tooltip
          contentStyle={{
            background: 'hsl(var(--popover))',
            border: '1px solid hsl(var(--border))',
            borderRadius: 8,
            fontSize: 12,
          }}
          formatter={(v: any) => `${(Number(v) * 100).toFixed(0)}%`}
          labelFormatter={(t) => formatTime(Number(t))}
        />
        <Line
          type="monotone"
          dataKey="score"
          stroke="#00f0ff"
          strokeWidth={2}
          dot={false}
          isAnimationActive={false}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
