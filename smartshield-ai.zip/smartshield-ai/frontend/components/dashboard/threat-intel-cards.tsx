'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useStore } from '@/lib/store';
import { Brain, Cpu, ShieldCheck, Zap } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

export function ThreatIntelCards() {
  const metrics = useStore((s) => s.metrics);
  const cpu = useStore((s) => s.cpu);

  const blockRate = metrics ? metrics.blockRate * 100 : 0;
  const botRate = metrics ? metrics.botRate * 100 : 0;
  const avgScore = metrics ? metrics.avgScore * 100 : 0;
  const cpuPct = cpu?.cpu ?? 0;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
      <IntelCard
        icon={ShieldCheck}
        title="Mitigation rate"
        value={`${blockRate.toFixed(1)}%`}
        sub={`${metrics?.blocked ?? 0} blocked / min`}
        progress={blockRate}
        color="text-cyber-red"
      />
      <IntelCard
        icon={Brain}
        title="Avg AI risk"
        value={`${avgScore.toFixed(1)}%`}
        sub="rolling 60s"
        progress={avgScore}
        color="text-primary"
      />
      <IntelCard
        icon={Zap}
        title="Bot pressure"
        value={`${botRate.toFixed(1)}%`}
        sub={`${metrics?.bot ?? 0} of ${metrics?.total ?? 0}`}
        progress={botRate}
        color="text-cyber-amber"
      />
      <IntelCard
        icon={Cpu}
        title="System load"
        value={`${cpuPct.toFixed(1)}%`}
        sub={cpu ? `${cpu.rssMb.toFixed(0)} MB rss` : ''}
        progress={cpuPct}
        color="text-cyber-violet"
      />
    </div>
  );
}

function IntelCard({
  icon: Icon,
  title,
  value,
  sub,
  progress,
  color,
}: {
  icon: any;
  title: string;
  value: string;
  sub: string;
  progress: number;
  color: string;
}) {
  return (
    <Card>
      <CardHeader className="pb-2 flex-row items-center gap-2 space-y-0">
        <Icon className={`h-4 w-4 ${color}`} />
        <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <p className={`text-2xl font-bold ${color}`}>{value}</p>
        <p className="text-xs text-muted-foreground mt-1">{sub}</p>
        <Progress value={Math.min(100, progress)} className="mt-3" />
      </CardContent>
    </Card>
  );
}
