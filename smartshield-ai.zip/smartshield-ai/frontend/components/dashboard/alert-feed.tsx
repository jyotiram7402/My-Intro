'use client';

import { useStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Bell } from 'lucide-react';
import { formatTime } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

export function AlertFeed() {
  const alerts = useStore((s) => s.alerts);
  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-cyber-amber" />
          Real-time alerts
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[260px] pr-3">
          <ul className="space-y-2">
            <AnimatePresence initial={false}>
              {alerts.length === 0 && (
                <li className="text-xs text-muted-foreground text-center py-6">No alerts.</li>
              )}
              {alerts.map((a) => (
                <motion.li
                  key={a.ts + a.title}
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0 }}
                  className="text-xs flex gap-2 p-2 rounded-md bg-muted/30"
                >
                  <span
                    className={`h-2 w-2 mt-1 rounded-full ${
                      a.level === 'error'
                        ? 'bg-cyber-red'
                        : a.level === 'warn'
                        ? 'bg-cyber-amber'
                        : 'bg-primary'
                    }`}
                  />
                  <div className="flex-1">
                    <p className="font-medium">{a.title}</p>
                    {a.detail && <p className="text-muted-foreground">{a.detail}</p>}
                  </div>
                  <span className="text-muted-foreground">{formatTime(a.ts)}</span>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
