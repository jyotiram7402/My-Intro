'use client';

import { useMemo } from 'react';
import { useStore } from '@/lib/store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

/**
 * Lightweight country-wise attack visualisation.
 *
 * We avoid heavy GIS libraries by using a flat heatmap-style ranked list
 * and small inline glyphs. For richer visualisation, swap this for
 * react-simple-maps + a TopoJSON of world borders.
 */

const COUNTRY_NAMES: Record<string, string> = {
  CN: 'China',
  RU: 'Russia',
  US: 'United States',
  IN: 'India',
  BR: 'Brazil',
  DE: 'Germany',
  GB: 'United Kingdom',
  FR: 'France',
  JP: 'Japan',
  KR: 'South Korea',
  NG: 'Nigeria',
  IR: 'Iran',
};
const FLAG = (code: string) =>
  code.toUpperCase().replace(/./g, (c) => String.fromCodePoint(127397 + c.charCodeAt(0)));

export function WorldMap() {
  const events = useStore((s) => s.events);

  const ranked = useMemo(() => {
    const counts: Record<string, { total: number; blocked: number; allowed: number }> = {};
    for (const e of events) {
      const code = e.country?.code || 'XX';
      if (!counts[code]) counts[code] = { total: 0, blocked: 0, allowed: 0 };
      counts[code].total += 1;
      if (e.action === 'block') counts[code].blocked += 1;
      else counts[code].allowed += 1;
    }
    return Object.entries(counts)
      .map(([code, v]) => ({ code, ...v }))
      .sort((a, b) => b.total - a.total);
  }, [events]);

  const max = ranked[0]?.total || 1;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Global attack distribution</CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {ranked.length === 0 && (
          <p className="text-xs text-muted-foreground py-8 text-center">
            No traffic recorded yet.
          </p>
        )}
        {ranked.slice(0, 8).map((c) => {
          const blockedPct = c.total ? (c.blocked / c.total) * 100 : 0;
          return (
            <div key={c.code} className="flex items-center gap-3">
              <span className="text-base w-8 text-center">{FLAG(c.code)}</span>
              <span className="text-xs w-32 truncate">{COUNTRY_NAMES[c.code] || c.code}</span>
              <div className="flex-1 h-2 bg-muted/40 rounded-full overflow-hidden flex">
                <div
                  className="bg-cyber-red"
                  style={{ width: `${(c.blocked / max) * 100}%` }}
                />
                <div
                  className="bg-primary/60"
                  style={{ width: `${(c.allowed / max) * 100}%` }}
                />
              </div>
              <span className="text-xs text-muted-foreground w-10 text-right">{c.total}</span>
              <span className="text-xs text-cyber-red w-10 text-right">{blockedPct.toFixed(0)}%</span>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
