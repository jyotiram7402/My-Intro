'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { adminApi } from '@/lib/api';
import { useStore } from '@/lib/store';
import { motion } from 'framer-motion';
import { ShieldCheck, ShieldAlert } from 'lucide-react';

export function ShieldToggle() {
  const shield = useStore((s) => s.shield);
  const setShield = useStore((s) => s.setShield);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    adminApi.state().then(setShield).catch(() => {});
  }, [setShield]);

  const onToggle = async (next: boolean) => {
    setBusy(true);
    try {
      const s = await adminApi.patch({ enabled: next });
      setShield(s);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card className="overflow-hidden">
      <div
        className={`absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent ${
          shield.enabled ? 'via-cyber-lime/60' : 'via-cyber-red/60'
        } to-transparent`}
      />
      <CardHeader className="flex-row items-center justify-between space-y-0">
        <div>
          <CardTitle className="flex items-center gap-2">
            {shield.enabled ? (
              <ShieldCheck className="h-4 w-4 text-cyber-lime" />
            ) : (
              <ShieldAlert className="h-4 w-4 text-cyber-red" />
            )}
            SmartShield AI
          </CardTitle>
          <CardDescription>
            {shield.enabled
              ? 'Adaptive mitigation is active. AI scoring + JS challenges enforced.'
              : 'Mitigation disabled. Traffic flowing unfiltered.'}
          </CardDescription>
        </div>
        <Switch checked={shield.enabled} onCheckedChange={onToggle} disabled={busy} />
      </CardHeader>
      <CardContent className="grid grid-cols-2 gap-4 text-sm">
        <Threshold
          label="Block above"
          value={shield.blockThreshold}
          color="text-cyber-red"
        />
        <Threshold
          label="Challenge above"
          value={shield.challengeThreshold}
          color="text-cyber-amber"
        />
      </CardContent>
      {shield.enabled && (
        <motion.div
          aria-hidden
          className="pointer-events-none absolute inset-0 mix-blend-screen"
          initial={{ y: '-100%' }}
          animate={{ y: '100%' }}
          transition={{ repeat: Infinity, duration: 4, ease: 'linear' }}
        >
          <div className="h-12 w-full bg-gradient-to-b from-transparent via-primary/10 to-transparent" />
        </motion.div>
      )}
    </Card>
  );
}

function Threshold({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="rounded-md border border-border/50 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`text-2xl font-bold ${color}`}>{(value * 100).toFixed(0)}%</p>
    </div>
  );
}
