'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { useStore } from '@/lib/store';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { formatTime, scoreColor } from '@/lib/utils';

export function LiveLog({ limit = 60 }: { limit?: number }) {
  const events = useStore((s) => s.events).slice(0, limit);

  return (
    <ScrollArea className="h-[420px] pr-3">
      <ul className="space-y-1.5 font-mono text-xs">
        <AnimatePresence initial={false}>
          {events.map((e) => (
            <motion.li
              key={e.requestId + e.ts}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.18 }}
              className="flex flex-wrap items-center gap-2 px-2 py-1.5 rounded-md hover:bg-muted/40"
            >
              <span className="text-muted-foreground w-16">{formatTime(e.ts)}</span>
              <ActionBadge action={e.action} />
              <span className="text-muted-foreground">{e.method}</span>
              <span className="truncate max-w-[180px]">{e.path}</span>
              <span className="text-muted-foreground">{e.ip}</span>
              {e.country && (
                <span className="text-[10px] text-muted-foreground">{e.country.code}</span>
              )}
              <span className={scoreColor(e.score)}>
                {(e.score * 100).toFixed(0)}%
              </span>
              <span className="text-muted-foreground truncate max-w-[200px]">
                {e.ua?.split(' ')[0]}
              </span>
            </motion.li>
          ))}
        </AnimatePresence>
        {!events.length && (
          <li className="text-muted-foreground text-center py-8">Waiting for traffic…</li>
        )}
      </ul>
    </ScrollArea>
  );
}

function ActionBadge({ action }: { action: string }) {
  if (action === 'block') return <Badge variant="destructive">BLOCK</Badge>;
  if (action === 'challenge') return <Badge variant="warning">CHALLENGE</Badge>;
  return <Badge variant="success">ALLOW</Badge>;
}
