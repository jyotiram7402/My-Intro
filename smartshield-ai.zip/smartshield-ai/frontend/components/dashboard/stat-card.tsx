'use client';

import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  accent = 'primary',
  trend,
}: {
  label: string;
  value: string | number;
  hint?: string;
  icon?: LucideIcon;
  accent?: 'primary' | 'violet' | 'lime' | 'amber' | 'red';
  trend?: { dir: 'up' | 'down'; value: string };
}) {
  const accentMap: Record<string, string> = {
    primary: 'text-primary border-primary/30 bg-primary/10',
    violet: 'text-cyber-violet border-cyber-violet/30 bg-cyber-violet/10',
    lime: 'text-cyber-lime border-cyber-lime/30 bg-cyber-lime/10',
    amber: 'text-cyber-amber border-cyber-amber/30 bg-cyber-amber/10',
    red: 'text-cyber-red border-cyber-red/30 bg-cyber-red/10',
  };
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="overflow-hidden relative">
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
        <CardContent className="p-5">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
              <p className="mt-2 text-3xl font-bold tracking-tight">{value}</p>
              {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
            </div>
            {Icon && (
              <div
                className={cn(
                  'p-2.5 rounded-lg border',
                  accentMap[accent]
                )}
              >
                <Icon className="h-5 w-5" />
              </div>
            )}
          </div>
          {trend && (
            <div className="mt-3 text-xs">
              <span className={cn(trend.dir === 'up' ? 'text-cyber-lime' : 'text-cyber-red')}>
                {trend.dir === 'up' ? '↑' : '↓'} {trend.value}
              </span>{' '}
              <span className="text-muted-foreground">vs last min</span>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
