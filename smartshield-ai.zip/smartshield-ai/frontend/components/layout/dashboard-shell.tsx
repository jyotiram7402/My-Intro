'use client';

import { Sidebar } from './sidebar';
import { Topbar } from './topbar';
import { useGatewayStream } from '@/hooks/useGatewayStream';

export function DashboardShell({ children }: { children: React.ReactNode }) {
  useGatewayStream();
  return (
    <div className="flex min-h-screen bg-background">
      {/* Background grid */}
      <div className="pointer-events-none fixed inset-0 cyber-grid opacity-50" />
      <div className="pointer-events-none fixed inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

      <Sidebar />
      <div className="flex-1 min-w-0 flex flex-col relative">
        <Topbar />
        <main className="flex-1 p-4 md:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
