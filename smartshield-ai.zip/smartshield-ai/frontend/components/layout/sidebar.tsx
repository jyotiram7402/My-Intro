'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Activity,
  Globe2,
  ListOrdered,
  Radar,
  Settings as SettingsIcon,
  Shield,
  Swords,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/', label: 'Overview', icon: Radar },
  { href: '/analytics', label: 'Analytics', icon: Activity },
  { href: '/threats', label: 'Threats', icon: Globe2 },
  { href: '/logs', label: 'Live Logs', icon: ListOrdered },
  { href: '/simulator', label: 'Simulator', icon: Swords },
  { href: '/settings', label: 'Settings', icon: SettingsIcon },
];

export function Sidebar() {
  const path = usePathname();
  return (
    <aside className="hidden md:flex flex-col w-60 shrink-0 border-r border-border/40 bg-card/30 backdrop-blur-xl">
      <div className="flex items-center gap-2 px-5 h-16 border-b border-border/40">
        <div className="grid place-items-center h-8 w-8 rounded-md bg-primary/15 text-primary">
          <Shield className="h-4 w-4" />
        </div>
        <div>
          <p className="text-sm font-semibold neon-text">SmartShield</p>
          <p className="text-[10px] uppercase tracking-widest text-muted-foreground">AI Defence</p>
        </div>
      </div>
      <nav className="flex-1 p-3 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = path === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors',
                active
                  ? 'bg-primary/10 text-primary border border-primary/30'
                  : 'text-muted-foreground hover:bg-muted/50 hover:text-foreground'
              )}
            >
              <Icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t border-border/40 text-[10px] text-muted-foreground">
        v1.0.0 · M.Tech research
      </div>
    </aside>
  );
}
