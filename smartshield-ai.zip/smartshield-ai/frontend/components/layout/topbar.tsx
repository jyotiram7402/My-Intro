'use client';

import { ThemeToggle } from './theme-toggle';
import { Badge } from '@/components/ui/badge';
import { useStore } from '@/lib/store';
import { Bell, Activity } from 'lucide-react';

export function Topbar() {
  const connected = useStore((s) => s.socketConnected);
  const shield = useStore((s) => s.shield);
  const alerts = useStore((s) => s.alerts);

  return (
    <header className="sticky top-0 z-30 flex items-center h-16 px-4 md:px-6 border-b border-border/40 bg-background/70 backdrop-blur-xl">
      <div className="flex items-center gap-3">
        <span className="relative flex h-2 w-2">
          {connected && (
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyber-lime/70 opacity-75" />
          )}
          <span
            className={
              connected
                ? 'relative inline-flex rounded-full h-2 w-2 bg-cyber-lime'
                : 'relative inline-flex rounded-full h-2 w-2 bg-cyber-red'
            }
          />
        </span>
        <p className="text-xs text-muted-foreground">
          {connected ? 'Gateway online' : 'Gateway offline'}
        </p>
      </div>

      <div className="ml-auto flex items-center gap-3">
        <Badge variant={shield.enabled ? 'success' : 'destructive'} className="gap-1">
          <Activity className="h-3 w-3" />
          {shield.enabled ? 'Shield ON' : 'Shield OFF'}
        </Badge>
        <button className="relative p-2 rounded-md hover:bg-muted/50">
          <Bell className="h-4 w-4" />
          {alerts.length > 0 && (
            <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-cyber-red" />
          )}
        </button>
        <ThemeToggle />
      </div>
    </header>
  );
}
