# SmartShield AI - Detection Engine

FastAPI service that returns a per-request risk score (0..1) using an
ensemble of four detectors:

| Model | Role | File |
|-------|------|------|
| Random Forest | supervised bot vs human | `app/ml/random_forest.py` |
| Isolation Forest | unsupervised anomaly | `app/ml/isolation_forest.py` |
| Autoencoder | reconstruction-error anomaly | `app/ml/autoencoder.py` |
| LSTM | per-IP temporal pattern | `app/ml/lstm_model.py` |

Each member is independent and weighted (configurable via env). If the
saved weights aren't on disk, that member transparently falls back to
a deterministic statistical scorer so the demo works untrained.

## Run

```bash
cp .env.example .env
python -m venv .venv
# activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Open http://localhost:8000/docs for the auto-generated API.

## Train

```bash
# 1. Generate a 20k-row labelled dataset
python -m training.generate_dataset --rows 20000

# 2. Train each model individually...
python -m training.train_random_forest
python -m training.train_isolation_forest
python -m training.train_autoencoder
python -m training.train_lstm

# ...or all of them
python -m training.train_all

# 3. Hot-reload without restarting
curl -X POST http://localhost:8000/reload
```

## Endpoints

| Method | Path | Notes |
|--------|------|-------|
| GET | `/health` | loaded models + ensemble weights |
| GET | `/info` | full configuration |
| POST | `/predict` | single-request scoring |
| POST | `/batch` | batch scoring |
| POST | `/reload` | reload models from disk |

## Predict request shape

```json
{
  "request_id": "uuid",
  "ip": "1.2.3.4",
  "ua": "Mozilla/5.0 ...",
  "path": "/login",
  "method": "POST",
  "features": {
    "request_rate_per_min": 12,
    "session_age_ms": 30000,
    "header_anomaly_score": 0.1,
    "ua_class": "human",
    "has_cookie": true,
    "accept_lang_count": 1,
    "referrer_present": true,
    "method_class": "mutating",
    "challenge_solved": false,
    "content_length": 124
  }
}
```

Response includes per-model contributions so the dashboard can render
explainable AI panels.
