"""
SmartShield AI - Detection Engine (FastAPI)

Entry-point for the AI service. Exposes:
    POST /predict   - score a single request feature vector
    POST /batch     - score a batch
    GET  /health    - liveness + ensemble status
    GET  /info      - which models are loaded, weights, thresholds
    POST /reload    - hot-reload models from disk

The service ships a graceful "untrained" mode: if no saved models are
found on disk, it falls back to a deterministic statistical scorer so
the demo dashboard works out-of-the-box. Run training/train_all.py to
fit and persist real models.
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes import router as api_router
from app.core.config import settings
from app.core.logging import setup_logging
from app.services.ensemble import ensemble


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging(settings.log_level)
    ensemble.load()
    yield


app = FastAPI(
    title="SmartShield AI - Detection Engine",
    version="1.0.0",
    description="Adaptive bot mitigation ML service.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)


@app.get("/")
def root():
    return {
        "service": "smartshield-ai-engine",
        "status": "ok",
        "docs": "/docs",
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=settings.port, reload=True)
