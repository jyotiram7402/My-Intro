"""Convenience runner: generate dataset (if missing) + train all four models."""
import os
import subprocess
import sys
from pathlib import Path


def run(cmd):
    print(f"\n>>> {' '.join(cmd)}\n")
    r = subprocess.run(cmd, check=False)
    if r.returncode != 0:
        print(f"!! {' '.join(cmd)} failed (exit {r.returncode})")
        sys.exit(r.returncode)


def main():
    root = Path(__file__).resolve().parent.parent
    os.chdir(root)
    if not Path("data/sample_traffic.csv").exists():
        run([sys.executable, "-m", "training.generate_dataset", "--rows", "20000"])
    run([sys.executable, "-m", "training.train_random_forest"])
    run([sys.executable, "-m", "training.train_isolation_forest"])
    run([sys.executable, "-m", "training.train_autoencoder"])
    run([sys.executable, "-m", "training.train_lstm"])
    print("\nAll models trained. Hit POST /reload on the engine to pick them up live.")


if __name__ == "__main__":
    main()
