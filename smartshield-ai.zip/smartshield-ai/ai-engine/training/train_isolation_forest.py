"""Train Isolation Forest on the *human-only* subset (one-class anomaly)."""
import argparse
import sys
from pathlib import Path
import pandas as pd
import joblib
from sklearn.ensemble import IsolationForest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.utils.featurize import encode_batch  # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/sample_traffic.csv")
    p.add_argument("--out", default="saved_models/isolation_forest.joblib")
    p.add_argument("--contamination", type=float, default=0.1)
    args = p.parse_args()

    df = pd.read_csv(args.data)
    humans = df[df["label"] == 0]
    print(f"Training Isolation Forest on {len(humans)} human samples")

    X = encode_batch(humans.to_dict(orient="records"))
    model = IsolationForest(
        n_estimators=200,
        contamination=args.contamination,
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X)

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, args.out)
    print(f"Saved -> {args.out}")


if __name__ == "__main__":
    main()
