"""
Train the LSTM sequence classifier.

We synthesize per-IP request sequences by grouping rows from the
sample dataset into pseudo-sessions of length SEQ_LEN, alternating
labels so the model learns burst patterns characteristic of bots.
"""
import argparse
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.utils.featurize import encode_batch, FEATURE_COLUMNS  # noqa: E402

SEQ_LEN = 12


def build_model(n_features: int):
    from tensorflow import keras
    from tensorflow.keras import layers

    inp = keras.Input(shape=(SEQ_LEN, n_features))
    x = layers.LSTM(32, return_sequences=False)(inp)
    x = layers.Dropout(0.2)(x)
    x = layers.Dense(16, activation="relu")(x)
    out = layers.Dense(1, activation="sigmoid")(x)
    model = keras.Model(inp, out)
    model.compile(optimizer=keras.optimizers.Adam(1e-3),
                  loss="binary_crossentropy",
                  metrics=["accuracy"])
    return model


def make_sequences(df: pd.DataFrame):
    humans = df[df["label"] == 0].to_dict(orient="records")
    bots = df[df["label"] == 1].to_dict(orient="records")
    X_seq, y_seq = [], []
    for batch, label in ((humans, 0), (bots, 1)):
        for i in range(0, len(batch) - SEQ_LEN, SEQ_LEN):
            chunk = batch[i:i + SEQ_LEN]
            X_seq.append(encode_batch(chunk))
            y_seq.append(label)
    X = np.array(X_seq, dtype=np.float32)
    y = np.array(y_seq, dtype=np.float32)
    return X, y


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/sample_traffic.csv")
    p.add_argument("--model-out", default="saved_models/lstm.h5")
    p.add_argument("--meta-out", default="saved_models/lstm_meta.json")
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch-size", type=int, default=64)
    args = p.parse_args()

    df = pd.read_csv(args.data).sample(frac=1.0, random_state=42).reset_index(drop=True)
    X, y = make_sequences(df)
    print(f"Sequences: {X.shape}, labels: {y.shape}")

    flat = X.reshape(-1, X.shape[-1])
    mean = flat.mean(axis=0)
    std = flat.std(axis=0) + 1e-6
    Xn = (X - mean) / std

    model = build_model(X.shape[-1])
    model.fit(Xn, y, validation_split=0.15, epochs=args.epochs,
              batch_size=args.batch_size, verbose=2)

    Path(args.model_out).parent.mkdir(parents=True, exist_ok=True)
    model.save(args.model_out)
    with open(args.meta_out, "w") as f:
        json.dump({
            "feature_columns": FEATURE_COLUMNS,
            "seq_len": SEQ_LEN,
            "mean": mean.tolist(),
            "std": std.tolist(),
        }, f, indent=2)
    print(f"Saved -> {args.model_out}")


if __name__ == "__main__":
    main()
