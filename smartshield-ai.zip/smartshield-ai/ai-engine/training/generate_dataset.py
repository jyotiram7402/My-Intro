"""
Synthesize a labelled traffic dataset for training & evaluation.

Produces ./data/sample_traffic.csv with columns:
    request_rate_per_min, session_age_ms, header_anomaly_score,
    ua_class, has_cookie, accept_lang_count, referrer_present,
    method_class, challenge_solved, content_length, label

`label` ∈ {0: human, 1: bot}.

Usage:
    python -m training.generate_dataset --rows 50000 --out data/sample_traffic.csv
"""
import argparse
import csv
import os
import random
from pathlib import Path

UA_CLASSES = ["human", "unknown", "bot-suspect", "bot-known"]
METHOD_CLASSES = ["safe", "mutating"]


def gen_human():
    return {
        "request_rate_per_min": max(0, int(random.gauss(8, 4))),
        "session_age_ms": int(random.uniform(2_000, 1_800_000)),
        "header_anomaly_score": round(min(1.0, max(0.0, random.gauss(0.05, 0.05))), 3),
        "ua_class": "human",
        "has_cookie": random.random() < 0.85,
        "accept_lang_count": random.choice([1, 1, 1, 2, 2, 3]),
        "referrer_present": random.random() < 0.7,
        "method_class": random.choices(METHOD_CLASSES, weights=[0.85, 0.15])[0],
        "challenge_solved": random.random() < 0.05,
        "content_length": random.choice([0, 0, 0, random.randint(0, 1500)]),
        "label": 0,
    }


def gen_bot():
    severity = random.random()
    return {
        "request_rate_per_min": max(20, int(random.gauss(120 if severity > 0.6 else 60, 40))),
        "session_age_ms": int(random.uniform(0, 30_000)),
        "header_anomaly_score": round(min(1.0, max(0.0, random.gauss(0.55, 0.2))), 3),
        "ua_class": random.choices(UA_CLASSES, weights=[0.05, 0.15, 0.4, 0.4])[0],
        "has_cookie": random.random() < 0.15,
        "accept_lang_count": random.choices([0, 1, 2], weights=[0.6, 0.3, 0.1])[0],
        "referrer_present": random.random() < 0.1,
        "method_class": random.choices(METHOD_CLASSES, weights=[0.7, 0.3])[0],
        "challenge_solved": False,
        "content_length": random.choice([0, 0, random.randint(0, 4000)]),
        "label": 1,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--rows", type=int, default=20_000)
    p.add_argument("--out", default="data/sample_traffic.csv")
    p.add_argument("--bot-ratio", type=float, default=0.45)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    random.seed(args.seed)
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    cols = list(gen_human().keys())
    with open(out_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        bots = int(args.rows * args.bot_ratio)
        humans = args.rows - bots
        for _ in range(humans):
            w.writerow(gen_human())
        for _ in range(bots):
            w.writerow(gen_bot())
    print(f"Wrote {args.rows} rows ({bots} bot / {humans} human) -> {out_path}")


if __name__ == "__main__":
    main()
