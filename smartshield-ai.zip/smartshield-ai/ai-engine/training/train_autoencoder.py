"""Train a small Autoencoder on the human subset."""
import argparse
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.utils.featurize import encode_batch, FEATURE_COLUMNS  # noqa: E402


def build_model(n_features: int):
    from tensorflow import keras
    from tensorflow.keras import layers

    inp = keras.Input(shape=(n_features,))
    x = layers.Dense(16, activation="relu")(inp)
    x = layers.Dense(8, activation="relu")(x)
    x = layers.Dense(16, activation="relu")(x)
    out = layers.Dense(n_features, activation="linear")(x)
    model = keras.Model(inp, out)
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="mse")
    return model


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/sample_traffic.csv")
    p.add_argument("--model-out", default="saved_models/autoencoder.h5")
    p.add_argument("--meta-out", default="saved_models/autoencoder_meta.json")
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--batch-size", type=int, default=128)
    args = p.parse_args()

    df = pd.read_csv(args.data)
    humans = df[df["label"] == 0]
    X = encode_batch(humans.to_dict(orient="records"))
    mean = X.mean(axis=0)
    std = X.std(axis=0) + 1e-6
    Xn = (X - mean) / std

    model = build_model(Xn.shape[1])
    model.fit(Xn, Xn, epochs=args.epochs, batch_size=args.batch_size, validation_split=0.1, verbose=2)
    recon = model.predict(Xn, verbose=0)
    errs = np.mean(np.square(Xn - recon), axis=1)
    threshold = float(np.quantile(errs, 0.95))

    Path(args.model_out).parent.mkdir(parents=True, exist_ok=True)
    model.save(args.model_out)
    with open(args.meta_out, "w") as f:
        json.dump(
            {
                "feature_columns": FEATURE_COLUMNS,
                "mean": mean.tolist(),
                "std": std.tolist(),
                "threshold": threshold,
            },
            f,
            indent=2,
        )
    print(f"Saved -> {args.model_out}, threshold={threshold:.4f}")


if __name__ == "__main__":
    main()
