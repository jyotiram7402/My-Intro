"""
Train a Random Forest classifier on the synthetic traffic dataset.

Usage:
    python -m training.train_random_forest \
        --data data/sample_traffic.csv \
        --out saved_models/random_forest.joblib
"""
import argparse
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.model_selection import train_test_split

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.utils.featurize import encode_batch, FEATURE_COLUMNS  # noqa: E402


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/sample_traffic.csv")
    p.add_argument("--out", default="saved_models/random_forest.joblib")
    p.add_argument("--n-estimators", type=int, default=200)
    p.add_argument("--max-depth", type=int, default=18)
    args = p.parse_args()

    df = pd.read_csv(args.data)
    X = encode_batch(df.to_dict(orient="records"))
    y = df["label"].astype(int).values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    model = RandomForestClassifier(
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        n_jobs=-1,
        class_weight="balanced",
        random_state=42,
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    print(classification_report(y_test, y_pred, target_names=["human", "bot"]))
    print(f"ROC-AUC: {roc_auc_score(y_test, y_proba):.4f}")

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, args.out)
    print(f"Saved -> {args.out}")
    print("Top features (importance):")
    for name, imp in sorted(zip(FEATURE_COLUMNS, model.feature_importances_),
                            key=lambda kv: -kv[1]):
        print(f"  {name:30s}  {imp:.4f}")


if __name__ == "__main__":
    main()
