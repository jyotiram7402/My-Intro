"""
Ensemble service — orchestrates the four detectors and combines their
scores into a single risk value.

The ensemble is intentionally simple (linear weighted sum) so that
ablation studies and threshold sweeps for the thesis are easy.
"""
import logging
from typing import Dict, List

from app.core.config import settings
from app.ml.random_forest import RandomForestDetector
from app.ml.isolation_forest import IsolationForestDetector
from app.ml.autoencoder import AutoencoderDetector
from app.ml.lstm_model import LSTMDetector
from app.utils.featurize import explain

logger = logging.getLogger(__name__)


class Ensemble:
    def __init__(self) -> None:
        self.rf = RandomForestDetector()
        self.iforest = IsolationForestDetector()
        self.ae = AutoencoderDetector()
        self.lstm = LSTMDetector()

    def load(self, force: bool = False) -> None:
        for m in (self.rf, self.iforest, self.ae, self.lstm):
            if force or not m.is_loaded():
                m.load(settings.model_dir)
        logger.info(
            "Ensemble ready. Trained models loaded: %s",
            self.loaded_models() or "[none — heuristic mode]",
        )

    def loaded_models(self) -> List[str]:
        return [m.name for m in (self.rf, self.iforest, self.ae, self.lstm) if m.is_loaded()]

    def weights(self) -> Dict[str, float]:
        return {
            "random_forest": settings.w_rf if settings.use_rf else 0.0,
            "isolation_forest": settings.w_iforest if settings.use_iforest else 0.0,
            "autoencoder": settings.w_ae if settings.use_ae else 0.0,
            "lstm": settings.w_lstm if settings.use_lstm else 0.0,
        }

    def info(self) -> Dict:
        return {
            "loaded_models": self.loaded_models(),
            "weights": self.weights(),
            "config": {
                "use_rf": settings.use_rf,
                "use_iforest": settings.use_iforest,
                "use_ae": settings.use_ae,
                "use_lstm": settings.use_lstm,
            },
        }

    def predict(self, features: Dict, raw: Dict) -> Dict:
        contributions = []
        weighted_sum = 0.0
        weight_total = 0.0

        if settings.use_rf:
            s = self.rf.score(features, raw)
            w = settings.w_rf
            weighted_sum += s * w
            weight_total += w
            contributions.append({"model": "random_forest", "score": round(s, 4), "weight": w})

        if settings.use_iforest:
            s = self.iforest.score(features, raw)
            w = settings.w_iforest
            weighted_sum += s * w
            weight_total += w
            contributions.append({"model": "isolation_forest", "score": round(s, 4), "weight": w})

        if settings.use_ae:
            s = self.ae.score(features, raw)
            w = settings.w_ae
            weighted_sum += s * w
            weight_total += w
            contributions.append({"model": "autoencoder", "score": round(s, 4), "weight": w})

        if settings.use_lstm:
            s = self.lstm.score(features, raw)
            w = settings.w_lstm
            weighted_sum += s * w
            weight_total += w
            contributions.append({"model": "lstm", "score": round(s, 4), "weight": w})

        score = weighted_sum / weight_total if weight_total else 0.0

        if score >= 0.7:
            classification = "bot"
        elif score >= 0.4:
            classification = "suspicious"
        else:
            classification = "human"

        return {
            "request_id": raw.get("request_id", ""),
            "score": round(float(score), 4),
            "classification": classification,
            "confidence": round(float(score if score >= 0.5 else 1 - score), 4),
            "model": "ensemble" if len(contributions) > 1 else (contributions[0]["model"] if contributions else "none"),
            "contributions": contributions,
            "explanations": explain(features, score),
        }


ensemble = Ensemble()
