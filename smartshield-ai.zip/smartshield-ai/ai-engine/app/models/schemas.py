from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class FeatureVector(BaseModel):
    request_rate_per_min: float = 0.0
    session_age_ms: float = 0.0
    header_anomaly_score: float = 0.0
    ua_class: str = "unknown"
    has_cookie: bool = False
    accept_lang_count: int = 0
    referrer_present: bool = False
    method_class: str = "safe"
    challenge_solved: bool = False
    content_length: int = 0


class PredictRequest(BaseModel):
    request_id: str = Field(..., description="Unique request identifier")
    features: FeatureVector
    ip: Optional[str] = None
    ua: Optional[str] = None
    path: Optional[str] = None
    method: Optional[str] = None


class BatchPredictRequest(BaseModel):
    items: List[PredictRequest]


class ContributionItem(BaseModel):
    model: str
    score: float
    weight: float


class PredictResponse(BaseModel):
    request_id: str
    score: float
    classification: str  # human | suspicious | bot
    confidence: float
    model: str
    contributions: List[ContributionItem]
    explanations: Optional[List[str]] = None


class BatchPredictResponse(BaseModel):
    items: List[PredictResponse]


class HealthResponse(BaseModel):
    status: str
    loaded_models: List[str]
    weights: Dict[str, float]
