from typing import List
from fastapi import APIRouter, HTTPException

from app.models.schemas import (
    PredictRequest,
    PredictResponse,
    BatchPredictRequest,
    BatchPredictResponse,
    HealthResponse,
)
from app.services.ensemble import ensemble

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(
        status="ok",
        loaded_models=ensemble.loaded_models(),
        weights=ensemble.weights(),
    )


@router.get("/info")
def info():
    return ensemble.info()


@router.post("/predict", response_model=PredictResponse)
def predict(payload: PredictRequest) -> PredictResponse:
    try:
        result = ensemble.predict(payload.features.dict(), payload.dict())
        return PredictResponse(**result)
    except Exception as e:  # noqa: BLE001 - want to surface trainer errors
        raise HTTPException(status_code=500, detail=str(e)) from e


@router.post("/batch", response_model=BatchPredictResponse)
def batch(payload: BatchPredictRequest) -> BatchPredictResponse:
    results = []
    for item in payload.items:
        results.append(ensemble.predict(item.features.dict(), item.dict()))
    return BatchPredictResponse(items=[PredictResponse(**r) for r in results])


@router.post("/reload")
def reload_models():
    ensemble.load(force=True)
    return {"reloaded": True, "loaded_models": ensemble.loaded_models()}
