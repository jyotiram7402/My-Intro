"""Autoencoder — reconstruction-error anomaly detector.

Stored as a Keras .h5 model with a sidecar `autoencoder_meta.json`
holding the normalisation params and reconstruction threshold.
"""
import os
import json
import logging
from typing import Dict, Optional
import numpy as np

from app.ml.base import BaseDetector
from app.utils.featurize import encode_features

logger = logging.getLogger(__name__)


class AutoencoderDetector(BaseDetector):
    name = "autoencoder"

    def __init__(self) -> None:
        super().__init__()
        self.model = None
        self.mean: Optional[np.ndarray] = None
        self.std: Optional[np.ndarray] = None
        self.threshold: float = 0.1

    def load(self, model_dir: str) -> None:
        h5_path = os.path.join(model_dir, "autoencoder.h5")
        meta_path = os.path.join(model_dir, "autoencoder_meta.json")
        if not (os.path.exists(h5_path) and os.path.exists(meta_path)):
            logger.info("Autoencoder weights not found — running heuristic mode")
            return
        try:
            from tensorflow import keras  # noqa: WPS433 (lazy import)
            self.model = keras.models.load_model(h5_path, compile=False)
            with open(meta_path) as f:
                meta = json.load(f)
            self.mean = np.array(meta["mean"], dtype=np.float32)
            self.std = np.array(meta["std"], dtype=np.float32) + 1e-6
            self.threshold = float(meta.get("threshold", 0.1))
            self._loaded = True
            logger.info("Autoencoder model loaded from %s", h5_path)
        except Exception as e:  # noqa: BLE001
            logger.exception("Failed to load Autoencoder: %s", e)

    def score(self, features: Dict, raw: Dict) -> float:
        x = encode_features(features)
        if self._loaded and self.model is not None and self.mean is not None and self.std is not None:
            try:
                xn = ((x - self.mean) / self.std).reshape(1, -1)
                recon = self.model.predict(xn, verbose=0)
                err = float(np.mean(np.square(xn - recon)))
                # Map err / threshold to 0..1
                ratio = err / max(self.threshold, 1e-6)
                return float(np.clip(ratio / 4.0, 0.0, 1.0))
            except Exception:  # noqa: BLE001
                pass
        # Heuristic fallback
        return float(np.clip(features.get("header_anomaly_score", 0) * 0.6 +
                             min(1.0, features.get("request_rate_per_min", 0) / 100) * 0.4,
                             0.0, 1.0))
