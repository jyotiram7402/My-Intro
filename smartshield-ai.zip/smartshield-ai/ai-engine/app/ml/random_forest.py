"""Random Forest classifier — supervised bot-vs-human probability."""
import os
import logging
from typing import Dict
import numpy as np
import joblib

from app.ml.base import BaseDetector
from app.utils.featurize import encode_features

logger = logging.getLogger(__name__)


class RandomForestDetector(BaseDetector):
    name = "random_forest"

    def __init__(self) -> None:
        super().__init__()
        self.model = None

    def load(self, model_dir: str) -> None:
        path = os.path.join(model_dir, "random_forest.joblib")
        if not os.path.exists(path):
            logger.info("RandomForest weights not found at %s — running heuristic mode", path)
            return
        try:
            self.model = joblib.load(path)
            self._loaded = True
            logger.info("RandomForest model loaded from %s", path)
        except Exception as e:  # noqa: BLE001
            logger.exception("Failed to load RandomForest: %s", e)

    def score(self, features: Dict, raw: Dict) -> float:
        x = encode_features(features).reshape(1, -1)
        if self._loaded and self.model is not None:
            try:
                proba = self.model.predict_proba(x)[0]
                # class index 1 == "bot" by training convention
                return float(proba[-1])
            except Exception:  # noqa: BLE001
                pass
        # Heuristic fallback (matches gateway heuristic so demo works untrained)
        return _heuristic(features)


def _heuristic(f: Dict) -> float:
    s = 0.0
    if f.get("ua_class") == "bot-known":
        s += 0.6
    elif f.get("ua_class") == "bot-suspect":
        s += 0.35
    elif f.get("ua_class") == "unknown":
        s += 0.2
    s += min(0.4, float(f.get("request_rate_per_min", 0)) / 200)
    s += float(f.get("header_anomaly_score", 0)) * 0.3
    if not f.get("has_cookie"):
        s += 0.05
    if not f.get("accept_lang_count"):
        s += 0.05
    return float(np.clip(s, 0.0, 1.0))
