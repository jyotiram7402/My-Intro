"""Isolation Forest — unsupervised anomaly score for traffic."""
import os
import logging
from typing import Dict
import numpy as np
import joblib

from app.ml.base import BaseDetector
from app.utils.featurize import encode_features

logger = logging.getLogger(__name__)


class IsolationForestDetector(BaseDetector):
    name = "isolation_forest"

    def __init__(self) -> None:
        super().__init__()
        self.model = None

    def load(self, model_dir: str) -> None:
        path = os.path.join(model_dir, "isolation_forest.joblib")
        if not os.path.exists(path):
            logger.info("IsolationForest weights not found at %s", path)
            return
        try:
            self.model = joblib.load(path)
            self._loaded = True
            logger.info("IsolationForest model loaded from %s", path)
        except Exception as e:  # noqa: BLE001
            logger.exception("Failed to load IsolationForest: %s", e)

    def score(self, features: Dict, raw: Dict) -> float:
        x = encode_features(features).reshape(1, -1)
        if self._loaded and self.model is not None:
            try:
                # decision_function: higher = more normal
                df = float(self.model.decision_function(x)[0])
                # Map [-0.3, 0.3] roughly to [1.0, 0.0] then clip
                norm = 0.5 - df  # df > 0 => normal => low score
                return float(np.clip(norm, 0.0, 1.0))
            except Exception:  # noqa: BLE001
                pass
        # Heuristic: requests/min spikes drive the anomaly score
        rate = float(features.get("request_rate_per_min", 0))
        anomaly = float(features.get("header_anomaly_score", 0))
        score = min(1.0, rate / 120.0) * 0.7 + anomaly * 0.3
        return float(np.clip(score, 0.0, 1.0))
