"""LSTM sequence model.

Operates on the per-IP request history (most recent N feature vectors)
to capture *temporal* patterns: bursty cadence, repeated paths, etc.

Per-IP histories are kept in memory with TTL eviction.
"""
import os
import json
import time
import logging
from collections import deque, defaultdict
from typing import Dict, Optional, Deque
import numpy as np

from app.ml.base import BaseDetector
from app.utils.featurize import encode_features

logger = logging.getLogger(__name__)

SEQ_LEN = 12
HISTORY_TTL = 600  # seconds


class LSTMDetector(BaseDetector):
    name = "lstm"

    def __init__(self) -> None:
        super().__init__()
        self.model = None
        self.mean: Optional[np.ndarray] = None
        self.std: Optional[np.ndarray] = None
        self.histories: dict = defaultdict(lambda: deque(maxlen=SEQ_LEN))
        self.last_seen: dict = {}

    def load(self, model_dir: str) -> None:
        h5_path = os.path.join(model_dir, "lstm.h5")
        meta_path = os.path.join(model_dir, "lstm_meta.json")
        if not (os.path.exists(h5_path) and os.path.exists(meta_path)):
            logger.info("LSTM weights not found — running heuristic mode")
            return
        try:
            from tensorflow import keras  # noqa: WPS433
            self.model = keras.models.load_model(h5_path, compile=False)
            with open(meta_path) as f:
                meta = json.load(f)
            self.mean = np.array(meta["mean"], dtype=np.float32)
            self.std = np.array(meta["std"], dtype=np.float32) + 1e-6
            self._loaded = True
            logger.info("LSTM model loaded from %s", h5_path)
        except Exception as e:  # noqa: BLE001
            logger.exception("Failed to load LSTM: %s", e)

    def _gc_histories(self) -> None:
        cut = time.time() - HISTORY_TTL
        stale = [k for k, t in self.last_seen.items() if t < cut]
        for k in stale:
            self.histories.pop(k, None)
            self.last_seen.pop(k, None)

    def score(self, features: Dict, raw: Dict) -> float:
        ip = raw.get("ip") or "unknown"
        self.last_seen[ip] = time.time()
        if len(self.last_seen) % 50 == 0:
            self._gc_histories()
        x = encode_features(features)
        self.histories[ip].append(x)
        seq = list(self.histories[ip])

        if self._loaded and self.model is not None and len(seq) >= 4 and self.mean is not None:
            try:
                # left-pad with last value
                pad = [seq[0]] * (SEQ_LEN - len(seq)) if len(seq) < SEQ_LEN else []
                arr = np.array(pad + seq, dtype=np.float32)
                arr = (arr - self.mean) / self.std
                arr = arr.reshape(1, SEQ_LEN, -1)
                p = self.model.predict(arr, verbose=0)
                return float(np.clip(p[0][0], 0.0, 1.0))
            except Exception:  # noqa: BLE001
                pass

        # Heuristic: "burstiness" = ratio of recent-rate to running average.
        rates = [float(s[0]) for s in seq]
        if len(rates) < 3:
            return float(np.clip(features.get("header_anomaly_score", 0) * 0.5, 0, 1))
        recent = np.mean(rates[-3:])
        baseline = np.mean(rates) + 1e-6
        burst = float(min(1.0, max(0.0, (recent / baseline - 1.0) / 2)))
        return float(np.clip(burst * 0.6 + features.get("header_anomaly_score", 0) * 0.4, 0, 1))
