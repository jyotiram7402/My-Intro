"""Abstract base for an ensemble member.

Each model exposes:
    - load(model_dir): load weights from disk if available
    - is_loaded(): bool
    - score(features_dict, raw_request) -> float in [0, 1]

`score` returns the *bot probability* (1.0 = surely bot).
"""

from abc import ABC, abstractmethod
from typing import Dict


class BaseDetector(ABC):
    name: str = "base"

    def __init__(self) -> None:
        self._loaded = False

    @abstractmethod
    def load(self, model_dir: str) -> None: ...

    def is_loaded(self) -> bool:
        return self._loaded

    @abstractmethod
    def score(self, features: Dict, raw: Dict) -> float: ...
