"""
Convert the dictionary-shaped feature vector that the gateway sends
into a fixed-order numerical array suitable for ML models.

Keeping the canonical column order in one place lets every model and
every training script agree on it.
"""
from typing import Dict, List, Tuple
import numpy as np

UA_CLASSES = ["human", "unknown", "bot-suspect", "bot-known"]
METHOD_CLASSES = ["safe", "mutating"]

FEATURE_COLUMNS: List[str] = [
    "request_rate_per_min",
    "session_age_ms",
    "header_anomaly_score",
    "ua_class_id",
    "has_cookie",
    "accept_lang_count",
    "referrer_present",
    "method_class_id",
    "challenge_solved",
    "content_length",
]


def encode_features(features: Dict) -> np.ndarray:
    """Single feature dict -> 1D numpy array."""
    ua_id = UA_CLASSES.index(features.get("ua_class", "unknown")) if features.get("ua_class") in UA_CLASSES else 1
    method_id = METHOD_CLASSES.index(features.get("method_class", "safe")) if features.get("method_class") in METHOD_CLASSES else 0
    vec = np.array(
        [
            float(features.get("request_rate_per_min", 0.0)),
            float(features.get("session_age_ms", 0.0)) / 1000.0,
            float(features.get("header_anomaly_score", 0.0)),
            float(ua_id),
            1.0 if features.get("has_cookie") else 0.0,
            float(features.get("accept_lang_count", 0)),
            1.0 if features.get("referrer_present") else 0.0,
            float(method_id),
            1.0 if features.get("challenge_solved") else 0.0,
            float(features.get("content_length", 0)) / 1000.0,
        ],
        dtype=np.float32,
    )
    return vec


def encode_batch(items: List[Dict]) -> np.ndarray:
    return np.stack([encode_features(it) for it in items])


def explain(features: Dict, score: float) -> List[str]:
    """Human-readable reasons that influenced a high score."""
    out: List[str] = []
    if features.get("ua_class") == "bot-known":
        out.append("User-agent matches a known automated client (e.g. curl/python-requests).")
    elif features.get("ua_class") == "bot-suspect":
        out.append("User-agent does not parse as a typical browser.")
    if features.get("header_anomaly_score", 0) > 0.4:
        out.append("Multiple expected HTTP headers are missing or implausible.")
    if features.get("request_rate_per_min", 0) > 60:
        out.append(f"Burst rate of ~{int(features['request_rate_per_min'])}/min from this client.")
    if not features.get("has_cookie"):
        out.append("No cookies sent — uncommon for a returning human.")
    if not features.get("accept_lang_count"):
        out.append("Missing Accept-Language header.")
    if not out and score > 0.5:
        out.append("Aggregate behavioural pattern is statistically anomalous.")
    if not out:
        out.append("No risk indicators triggered.")
    return out
