"""Configuration loaded from environment variables."""
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).lower() == "true"


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass
class Settings:
    port: int = int(os.getenv("AI_PORT", "8000"))
    model_dir: str = os.getenv("MODEL_DIR", "./saved_models")
    log_level: str = os.getenv("LOG_LEVEL", "info")

    use_rf: bool = _bool("USE_RANDOM_FOREST", True)
    use_iforest: bool = _bool("USE_ISOLATION_FOREST", True)
    use_ae: bool = _bool("USE_AUTOENCODER", True)
    use_lstm: bool = _bool("USE_LSTM", True)

    w_rf: float = _float("W_RANDOM_FOREST", 0.40)
    w_iforest: float = _float("W_ISOLATION_FOREST", 0.20)
    w_ae: float = _float("W_AUTOENCODER", 0.20)
    w_lstm: float = _float("W_LSTM", 0.20)


settings = Settings()
