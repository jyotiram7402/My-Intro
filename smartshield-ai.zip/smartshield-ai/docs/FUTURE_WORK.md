# Future Work

A non-exhaustive backlog of enhancements aligned with the M.Tech thesis.

## Modeling
- **Adaptive PoW difficulty.** Tune the SHA-256 prefix target zeros
  by AI risk score so bots pay exponentially more per request.
- **Behavioural session graphs.** GraphSAGE / GAT over per-IP session
  edges to detect coordinated multi-IP campaigns.
- **Online learning.** Operator labels from `/threats` page feed back
  into the Random Forest via incremental retraining.
- **Transformer encoder.** Replace the LSTM with a small attention
  encoder for richer temporal modelling.
- **GAN-augmented dataset.** Generate hard-negative bot traffic via a
  conditional WGAN to expand training coverage.

## System
- **Distributed state.** Replace in-memory rate-limit + LSTM history
  with Redis so the gateway can scale horizontally.
- **eBPF kernel-level drop.** For the worst offenders, push deny rules
  via XDP — saves all userland CPU.
- **Edge deployment.** Compile the gateway to a Cloudflare Worker /
  Fastly Compute@Edge target.
- **WASM AI inference.** Compile the RF + Autoencoder to ONNX +
  WebAssembly so scoring runs at the edge.

## Observability
- **OpenTelemetry traces.** Span every pipeline stage; ship to Jaeger.
- **Prometheus metrics.** Expose RPS / score distribution / action
  counts for Grafana boards.
- **Anomaly explanations.** SHAP values for the Random Forest, surfaced
  in the live log.

## UX
- **Per-IP drill-down.** Click any IP → full session timeline + raw
  features, comments, label-correction button.
- **Replay mode.** Re-feed historical traffic at adjustable speed for
  classroom demos.
- **Audit log.** Append-only history of operator actions (toggle,
  threshold change, manual block).

## Research questions still open
- How does ensemble weight choice affect F1 in the presence of
  concept drift?
- Is the JS challenge alone sufficient to defeat ~95% of low-effort
  bot operators? At what point does it become a UX tax?
- Can federated training across SMBs improve catch-rates without
  exchanging raw traffic?
