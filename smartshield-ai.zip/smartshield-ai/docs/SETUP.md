# Setup Guide

Tested on Windows 11, macOS 14, and Ubuntu 24.04.

## 0. Prerequisites

| Tool | Version | Why |
|------|---------|-----|
| Node.js | 20 LTS or newer | Frontend, backend, dummy site, simulator |
| Python | 3.11+ | AI engine + training scripts |
| MongoDB | 6+ (local or Atlas) | Persisted traffic logs (optional but recommended) |
| Git | any | Cloning the repo |

## 1. Clone

```bash
git clone <repo-url> smartshield-ai
cd smartshield-ai
```

## 2. Create env files

Each module ships a `.env.example` &mdash; copy and edit:

```bash
cp backend/.env.example         backend/.env
cp ai-engine/.env.example       ai-engine/.env
cp dummy-website/.env.example   dummy-website/.env
cp frontend/.env.example        frontend/.env.local
```

Defaults will work locally if MongoDB is at `mongodb://localhost:27017`.

## 3. Start the AI engine

```bash
cd ai-engine
python -m venv .venv

# Windows
.\.venv\Scripts\Activate.ps1
# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

> Optional: train the models first.
> ```bash
> python -m training.generate_dataset --rows 20000
> python -m training.train_all
> # then in another shell:
> curl -X POST http://localhost:8000/reload
> ```

The engine **runs untrained** by default — it falls back to the
deterministic statistical scorer so you can validate the full demo
without training first.

## 4. Start the dummy website

```bash
cd ../dummy-website
npm install
npm start    # http://localhost:4000
```

## 5. Start the gateway

```bash
cd ../backend
npm install
npm run dev    # http://localhost:5000
```

`http://localhost:5000/proxy/` should now serve the dummy website
through the SmartShield pipeline.

## 6. Start the dashboard

```bash
cd ../frontend
npm install
npm run dev    # http://localhost:3000
```

## 7. Run an attack (optional)

From the dashboard's **Simulator** page, *or* from the command line:

```bash
cd ../attack-simulator
npm install
node simulator.js --mode=bot --concurrency=30 --duration=60
```

## Demonstration sequence

1. Open the dashboard at `http://localhost:3000`.
2. **Disable** SmartShield (Settings → toggle off, or top-right widget).
3. Run `--mode=flood --concurrency=80 --duration=20`.
   Watch CPU spike, traffic chart turn into a wall of green allowed
   requests, dummy site latency rise.
4. **Enable** SmartShield.
5. Run the same attack again. Risk score climbs, JS challenges issued,
   most attackers blocked, CPU stays bounded.

## Troubleshooting

- **Mongo connection failed** — the gateway will still run; persisted
  history endpoints will return 503 but live streaming works.
- **AI engine unreachable** — gateway falls back to the heuristic
  scorer; behaviour is similar but less accurate.
- **CORS errors in browser** — set `FRONTEND_ORIGIN` in `backend/.env`
  to match the dashboard's URL.
- **Port already in use** — change the `PORT` in the relevant `.env`.
