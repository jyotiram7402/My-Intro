# Architecture

## High-level diagram

```
+------------------+       +------------------+       +------------------+
|  Real Browsers   |       | Attack Simulator |       |   Dashboard UI   |
|  (humans)        |       |  (bot, flood,…)  |       |   (Next.js)      |
+--------+---------+       +---------+--------+       +---------+--------+
         |                           |                           |
         |  HTTP / proxy             |  HTTP / proxy             |  Socket.IO
         v                           v                           v
+------------------------------------------------------------------------+
|                      SmartShield Gateway (Node.js)                     |
|                                                                        |
|  +------------+   +----------------+   +-------------+   +----------+  |
|  | rate limit |-->| feature        |-->| AI scorer   |-->| mitigator|  |
|  | per-IP     |   | extractor      |   | (FastAPI)   |   |          |  |
|  +------------+   +----------------+   +-------------+   +----+-----+  |
|                                                               |        |
|                          + traffic log -> ring buffer + Mongo |        |
|                          + WebSocket broadcaster              |        |
+--------------------------+--------------------------+---------+--------+
                           |                          |
                           v                          v
                   +---------------+          +-----------------+
                   | Dummy Website |          |   MongoDB       |
                   | (Express)     |          |   logs / IPs    |
                   +---------------+          +-----------------+
                                                       ^
                                                       |
                                              +--------+--------+
                                              |   AI Engine     |
                                              |  (FastAPI + TF) |
                                              |  RF / IF / AE / |
                                              |  LSTM ensemble  |
                                              +-----------------+
```

## Request lifecycle

1. **Ingress.** Any request to `/proxy/*` enters the gateway pipeline.
2. **Rate limit.** Per-IP token bucket gives a coarse first defence
   against trivial floods.
3. **Feature extraction.** A behavioural feature vector is built:
   request rate, header anomaly score, UA class, cookie presence, etc.
4. **AI scoring.** The vector is POST-ed to the FastAPI engine, which
   runs all enabled detectors (Random Forest, Isolation Forest,
   Autoencoder, LSTM) and returns an aggregated score plus per-model
   contributions.
5. **Mitigation.** The gateway maps the score to one of three actions:
   - score ≥ block_threshold → 403 with logged event
   - score ≥ challenge_threshold → JS proof-of-work challenge
   - else → forwarded to the dummy site
6. **Logging + telemetry.** The event is pushed to a ring buffer, an
   async Mongo write, and emitted on the Socket.IO `traffic` channel for
   the dashboard.

## Data model

### `traffic_events` (Mongo)

```
{
  requestId, ts, ip, country: { code, name, lat, lng },
  method, path, ua,
  score, classification, action, bypass,
  modelSource, modelConfidence,
  features: {
    request_rate_per_min, session_age_ms, header_anomaly_score,
    ua_class, has_cookie, accept_lang_count,
    referrer_present, method_class, challenge_solved, content_length
  }
}
```

### `suspicious_ips` (Mongo)

Aggregated per-IP roll-up for the threats page (block count,
challenge count, last seen, average score).

## Streaming protocol

Socket.IO room `dashboard` receives:

| Event | Cadence | Payload |
|-------|---------|---------|
| `hello` | once on connect | initial snapshot |
| `traffic` | per request | `TrafficEvent` |
| `cpu` | 1 Hz | `{ ts, cpu, rssMb, heapMb, load1 }` |
| `metrics` | 1 Hz | rolling 60s metrics |
| `alert` | on event | `{ level, title, detail?, ts }` |
| `shield` | on toggle | `{ enabled, blockThreshold, challengeThreshold }` |

## Ensemble layout

```
        +---------------------+
        |  Feature vector     |
        +----------+----------+
                   |
        +----------+-----------+----------+----------+
        |          |           |          |          |
        v          v           v          v          v
   RandomForest  IsolForest  Autoenc.  LSTM (seq)
        |          |           |          |
        +----+-----+-----+-----+----+-----+
             |           |          |
             v           v          v
              weighted sum -> score in [0, 1]
                                |
                                v
                       classification + actions
```

Weights and on/off toggles are environment-driven; ablation experiments
require zero code changes.
