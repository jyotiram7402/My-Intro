# API Reference

All endpoints live on the **gateway** at `http://localhost:5000`
unless otherwise noted. The AI engine endpoints live on the engine at
`http://localhost:8000`.

---

## Gateway

### `GET /healthz`
Liveness check. Returns `{ ok: true, service: "smartshield-gateway" }`.

### `GET /api/admin/state`
Snapshot of the shield: `{ enabled, blockThreshold, challengeThreshold, challenge: { ... } }`.

### `PATCH /api/admin/state`
Update toggle / thresholds. Accepts any subset of:
```json
{ "enabled": true, "blockThreshold": 0.85, "challengeThreshold": 0.55 }
```

### `GET /api/metrics/summary`
Latest rolling-60s metrics + latest CPU sample.

### `GET /api/metrics/timeseries?bucket=1000&window=120000`
Bucketed traffic + CPU history.

### `GET /api/metrics/recent?n=100`
Last N events from the in-memory ring buffer.

### `GET /api/metrics/history?limit=200`
Persisted events from MongoDB (most recent first).

### `GET /api/metrics/countries`
Country-code → request count, last 60 s.

### `POST /api/challenge/issue`
Issue a JS proof-of-work challenge for the calling IP.
Response: `{ id, salt, target, expiresAt, algorithm }`.

### `POST /api/challenge/verify`
Body:
```json
{
  "id": "uuid-from-issue",
  "nonce": 12345,
  "signals": {
    "mouseMoves": 12,
    "screen": { "width": 1920, "height": 1080 },
    "timezone": "Europe/London",
    "solveMs": 240
  }
}
```
Returns `{ ok: true, token, plausibility }` on success.

### `GET /api/challenge/page`
Self-contained HTML challenge page (used for redirected flagged clients).

### `POST /api/shield/simulate/start`
Body `{ mode: "bot"|"human"|"flood"|"mixed", concurrency: 25, durationSec: 30, targetPath?: "/" }`.

### `POST /api/shield/simulate/stop`
Stop any active in-process simulator.

### `ANY /proxy/*`
Protected forward to the dummy site. All requests pass through:
rate limiter → feature extractor → AI scorer → mitigator.

---

## AI Engine

### `GET /health`
`{ status, loaded_models, weights }`.

### `GET /info`
Configuration + ensemble snapshot.

### `POST /predict`
Body:
```json
{
  "request_id": "abc",
  "ip": "1.2.3.4",
  "ua": "Mozilla/5.0 ...",
  "path": "/login",
  "method": "POST",
  "features": {
    "request_rate_per_min": 12,
    "session_age_ms": 30000,
    "header_anomaly_score": 0.1,
    "ua_class": "human",
    "has_cookie": true,
    "accept_lang_count": 1,
    "referrer_present": true,
    "method_class": "mutating",
    "challenge_solved": false,
    "content_length": 124
  }
}
```
Response:
```json
{
  "request_id": "abc",
  "score": 0.13,
  "classification": "human",
  "confidence": 0.87,
  "model": "ensemble",
  "contributions": [
    { "model": "random_forest",     "score": 0.10, "weight": 0.40 },
    { "model": "isolation_forest",  "score": 0.20, "weight": 0.20 },
    { "model": "autoencoder",       "score": 0.12, "weight": 0.20 },
    { "model": "lstm",              "score": 0.15, "weight": 0.20 }
  ],
  "explanations": ["No risk indicators triggered."]
}
```

### `POST /batch`
Same shape as `/predict` but with `{ items: [...] }`.

### `POST /reload`
Reload trained model weights from disk without restarting the process.
