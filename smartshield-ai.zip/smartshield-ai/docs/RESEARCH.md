# Research Notes

> **SmartShield AI: Adaptive Bot Mitigation & Traffic Intelligence
> Using Deep Learning Techniques** &mdash; M.Tech research project, 2026.

---

## 1. Motivation

In 2024 a US-based e-commerce site experienced a sustained automated
traffic event in which CPU utilization climbed close to 100% across all
container instances. The site was unavailable for several hours,
causing a measurable drop in revenue and reputation.

Production-grade enterprise mitigation services (e.g. JS-challenge
products by major CDN vendors) were effective but financially
prohibitive for smaller businesses. This project asks:

> *Can a small/medium business deploy adaptive, behaviour-aware bot
> mitigation in-house, using only commodity ML libraries and an open
> architecture, and obtain protection comparable to commercial systems
> at a fraction of the operating cost?*

SmartShield AI is the prototype designed to answer that question.

---

## 2. Threat model

We assume an adversary operating one or more of the following profiles:

| Profile | Technique | Typical signal |
|---------|-----------|----------------|
| Aggregator scraper | high-rate GETs, naked UA | `python-requests`, missing headers |
| Credential stuffer | rapid POSTs to /login | high error rate, randomised passwords |
| Volumetric flood | shallow burst from many IPs | sudden RPS spike, low cookie rate |
| Sophisticated headless | full Chromium, varied UA | low header anomaly, but burst cadence |

We do **not** target nation-state-grade adversaries with residential
proxy networks and full browser automation, although the dataset
generation pipeline can be extended to that regime.

---

## 3. Feature engineering

The behavioural feature vector is built per request. Categorical
features are integer-encoded; numerical features are kept on natural
scales and normalised at the model boundary.

| Feature | Type | Rationale |
|---------|------|-----------|
| `request_rate_per_min` | float | Bots tend to be bursty / continuous |
| `session_age_ms` | float | Bots usually have very short sessions |
| `header_anomaly_score` | float ∈ [0,1] | Heuristic over header presence/coherence |
| `ua_class` | int(4) | human / unknown / bot-suspect / bot-known |
| `has_cookie` | bool | Returning humans send cookies, scripts rarely do |
| `accept_lang_count` | int | Humans set `Accept-Language`, scripts seldom |
| `referrer_present` | bool | Browsing has a referrer chain; bots don't |
| `method_class` | int(2) | safe / mutating |
| `challenge_solved` | bool | Bypass flag for previously-verified clients |
| `content_length` | float | Anomalously large bodies → upload abuse |

---

## 4. Models

### 4.1 Random Forest (supervised)
- 200 trees, depth 18, `class_weight="balanced"`.
- Fast inference; provides feature importances for interpretability.
- Trained directly on labelled (`label ∈ {0,1}`) data.

### 4.2 Isolation Forest (one-class)
- Trained on the *human-only* subset.
- Detects anomalous points without bot labels.
- Good catch-rate for novel automation that doesn't match training UAs.

### 4.3 Autoencoder (deep one-class)
- 10 → 16 → 8 → 16 → 10 dense bottleneck.
- Reconstruction error `> 95th percentile of human errors` is anomalous.
- Captures non-linear correlations across features.

### 4.4 LSTM (sequence)
- Per-IP rolling history of length 12.
- Single LSTM(32) → Dropout → Dense → sigmoid.
- Captures *temporal* patterns: bursts, repetition, cadence.

### 4.5 Ensemble
- Linear weighted sum of the four detector scores (env-tunable).
- Defaults: RF=0.40, IF=0.20, AE=0.20, LSTM=0.20.
- Score ∈ [0, 1]; thresholds map to `human / suspicious / bot`.

---

## 5. Adaptive mitigation

The mitigation policy maps the ensemble score onto three actions:

| Score band | Action | Rationale |
|------------|--------|-----------|
| `< challenge_threshold` | allow | unlikely bot — preserve UX |
| `≥ challenge_threshold` | challenge (JS PoW) | force per-client cost |
| `≥ block_threshold` | block (403) | high confidence — drop |

**Why a JS challenge?**
The JS challenge (a) raises the per-request *cost* for an attacker,
(b) requires a real JS engine to solve, and (c) checks *behavioural
plausibility signals* (mouse moves, screen size, timezone, solve time).
It is *adaptive* because difficulty scales with risk score (future
work), and reusable because a successful solve mints a token valid for
the configured TTL.

The challenge implementation is **original**: it does not replicate
any commercial product. The PoW algorithm is a vanilla
hashcash-style SHA-256 prefix search seeded with a server salt and an
HMAC-signed token.

---

## 6. Evaluation methodology

For thesis-level evaluation we recommend the following experiments:

1. **Per-model ablation.** Disable each detector in turn; measure
   precision, recall, F1 on a held-out test set.
2. **Threshold sweep.** Move `(challenge_threshold, block_threshold)`
   across `[0, 1]` to plot precision/recall curves.
3. **Concept drift.** Re-train monthly on freshly-collected traffic;
   measure decay in F1 between snapshots.
4. **Latency budget.** Wall-clock of the full pipeline at p50, p95,
   p99 under loads of 50, 200, 1000 RPS.
5. **CPU saving.** Run the dummy site behind the gateway with shield
   on/off during a synthetic flood; report CPU%.

The dashboard's `/analytics` and `/threats` pages provide most of the
metrics needed for these experiments.

---

## 7. Limitations

- The synthetic dataset under-represents sophisticated headless
  browsers; real-traffic evaluation is needed for thesis defence.
- The geo-IP lookup is deterministic-hash based for demo convenience.
  Replace with MaxMind GeoLite2 for production.
- Per-IP history for the LSTM is in-memory; clusters need shared
  state (Redis or similar) for horizontal scale.

---

## 8. Future work

- **Adaptive challenge difficulty.** Increase PoW target zeros with
  rising risk score (already supported by client; tune server-side).
- **GraphSAGE on session graphs.** Cross-IP behavioural clustering.
- **Federated training.** Share model updates between SMBs without
  sharing traffic logs.
- **eBPF integration.** Drop attackers at the kernel for the worst
  offenders (saves CPU completely).
- **Active learning loop.** Operator clicks on the dashboard
  re-label events; weights flow back into RF + AE training.
