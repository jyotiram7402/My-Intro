# Dashboard Screenshots (placeholders)

> These are placeholders for the project report. Capture screenshots
> after running the demonstration sequence in `SETUP.md` and drop them
> into `docs/screenshots/`.

| File | Caption |
|------|---------|
| `01-overview.png` | Operations dashboard at idle (low CPU, mostly allowed traffic) |
| `02-attack-shield-off.png` | Bot flood with SmartShield disabled — CPU spikes, all traffic allowed |
| `03-attack-shield-on.png` | Same flood with SmartShield enabled — bots blocked, CPU bounded |
| `04-threats-map.png` | Country-wise distribution after a 60s mixed run |
| `05-simulator-running.png` | Simulator page mid-run with live status badge |
| `06-settings.png` | Threshold tuning sliders |
| `07-live-log.png` | Real-time event log feed |
| `08-classification-pie.png` | Human / suspicious / bot breakdown |
| `09-ai-explainability.png` | Per-model contribution and explanations |

Suggested resolution: 1920×1080. Use the dark theme for the report
front matter and the light theme for printed appendices.
