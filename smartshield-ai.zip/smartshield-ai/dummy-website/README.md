# Dummy Vulnerable Website

A tiny e-commerce-styled site that sits behind the SmartShield gateway.
Each request runs a synthetic CPU-bound loop (`WORK_ITERATIONS`) so that
bot floods produce visible CPU spikes in the dashboard.

## Run

```bash
npm install
npm start    # http://localhost:4000
```

Open `http://localhost:5000/proxy/` to access this site through the
SmartShield gateway (recommended).

## Endpoints

- `GET /` — landing page
- `GET /api/products` — list products (CPU work)
- `GET /api/product/:id` — single product
- `POST /api/cart` — add to cart
- `GET /login` — login page
- `GET /healthz` — liveness
