/**
 * Dummy vulnerable e-commerce website used as the protected origin.
 *
 * It deliberately performs a small CPU-bound calculation per request so
 * that bot floods produce visible CPU pressure in the dashboard graphs.
 */

const express = require('express');
const morgan = require('morgan');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(morgan('tiny'));
app.use(express.static(path.join(__dirname, 'public')));

// Simulated CPU work — knob for the demo. Higher = the site falls over
// faster under load, which makes the mitigation effect more dramatic.
const WORK_ITERATIONS = Number(process.env.WORK_ITERATIONS || 80_000);

function simulateCpu() {
  let x = 0;
  for (let i = 0; i < WORK_ITERATIONS; i++) {
    x += Math.sqrt(i * Math.random()) * Math.sin(i);
  }
  return x;
}

const PRODUCTS = [
  { id: 'p1', name: 'Hex Socket Cap', price: 4.99, stock: 142 },
  { id: 'p2', name: 'Stainless Bolt M8', price: 1.20, stock: 980 },
  { id: 'p3', name: 'Aluminum Flange', price: 12.50, stock: 56 },
  { id: 'p4', name: 'Industrial Hinge', price: 8.75, stock: 210 },
  { id: 'p5', name: 'Cable Gland 16mm', price: 3.40, stock: 433 },
];

app.get('/', (_req, res) => {
  simulateCpu();
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/api/products', (_req, res) => {
  simulateCpu();
  res.json(PRODUCTS);
});

app.get('/api/product/:id', (req, res) => {
  simulateCpu();
  const p = PRODUCTS.find((x) => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'not_found' });
  res.json(p);
});

app.post('/api/cart', express.json(), (_req, res) => {
  simulateCpu();
  res.json({ ok: true, cartId: Math.random().toString(36).slice(2) });
});

app.get('/login', (_req, res) => {
  simulateCpu();
  res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/healthz', (_req, res) => res.json({ ok: true, service: 'dummy-site' }));

app.listen(PORT, () => {
  console.log(`Dummy site listening on http://localhost:${PORT}`);
  console.log(`Work iterations per request: ${WORK_ITERATIONS}`);
});
