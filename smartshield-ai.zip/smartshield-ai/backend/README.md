# SmartShield Gateway (Backend)

Node.js + Express gateway that sits in front of the dummy vulnerable
website. Every request is enriched with behavioural features, scored
by the AI engine, and either allowed, challenged, or blocked.

## Run

```bash
cp .env.example .env
npm install
npm run dev   # http://localhost:5000
```

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/healthz` | liveness |
| GET | `/api/admin/state` | shield snapshot |
| PATCH | `/api/admin/state` | toggle shield / thresholds |
| GET | `/api/metrics/summary` | latest metrics + cpu |
| GET | `/api/metrics/timeseries` | time-bucketed metrics |
| GET | `/api/metrics/recent` | last N events (in-mem) |
| GET | `/api/metrics/history` | persisted events (Mongo) |
| GET | `/api/metrics/countries` | country breakdown |
| POST | `/api/challenge/issue` | issue PoW challenge |
| POST | `/api/challenge/verify` | verify nonce + signals |
| GET | `/api/challenge/page` | self-contained HTML challenge |
| POST | `/api/shield/simulate/start` | start in-process attack |
| POST | `/api/shield/simulate/stop` | stop in-process attack |
| ANY | `/proxy/*` | protected forward to dummy site |

## Pipeline order

1. `rateLimiter` — first-line per-IP token bucket
2. `featureExtractor` — builds behaviour vector
3. `aiScorer` — calls FastAPI `/predict` (heuristic fallback if down)
4. `mitigator` — converts score → allow / challenge / block
5. `proxy` — forwards allowed requests to the dummy site

## WebSocket events (Socket.IO)

| Event | Payload |
|-------|---------|
| `hello` | initial state snapshot |
| `traffic` | per-request event |
| `cpu` | 1Hz cpu/mem sample |
| `metrics` | 1Hz rolling metrics |
| `alert` | shield/simulator alerts |
| `shield` | shield state change |
