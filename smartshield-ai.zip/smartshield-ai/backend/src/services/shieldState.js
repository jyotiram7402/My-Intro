/**
 * Singleton state for the global shield toggle (enabled/disabled).
 * Allows the dashboard to flip protection on and off live, without
 * restarting the gateway.
 */

const config = require('../config');

let enabled = config.shield.enabled;
let blockThreshold = config.shield.blockThreshold;
let challengeThreshold = config.shield.challengeThreshold;

module.exports = {
  isEnabled: () => enabled,
  setEnabled(v) {
    enabled = !!v;
    return enabled;
  },
  getThresholds: () => ({ block: blockThreshold, challenge: challengeThreshold }),
  setThresholds({ block, challenge }) {
    if (typeof block === 'number') blockThreshold = block;
    if (typeof challenge === 'number') challengeThreshold = challenge;
    return this.getThresholds();
  },
  snapshot: () => ({
    enabled,
    blockThreshold,
    challengeThreshold,
  }),
};
