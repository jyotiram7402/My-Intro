/**
 * JS Challenge Service
 *
 * Implements an *original*, lightweight proof-of-work + behavioural
 * challenge scheme inspired by enterprise anti-bot systems.
 *
 * Flow:
 *   1. Server issues a challenge: { id, salt, target, expiresAt }.
 *   2. Browser computes a SHA-256 hash of (salt + nonce) and finds a
 *      nonce such that the hex digest starts with `target` zeros.
 *      It also collects benign signals (mouse moves, screen size, tz).
 *   3. Browser submits { id, nonce, signals } to /api/challenge/verify.
 *   4. Server validates PoW + signals, returns a signed token.
 *   5. Client attaches `x-shield-token: <token>` to subsequent requests.
 *
 * The PoW difficulty is tuned to be ~50–300 ms in modern browsers and
 * roughly 10×–50× slower for naive script clients. This is deliberately
 * an *educational* implementation: it is not a substitute for a hardened
 * commercial CAPTCHA.
 */

const crypto = require('crypto');
const { v4: uuid } = require('uuid');
const config = require('../config');

const issuedChallenges = new Map(); // id -> {ip, salt, target, expiresAt}
const tokenStore = new Map(); // token -> {ip, expiresAt}

function cleanup() {
  const now = Date.now();
  for (const [id, c] of issuedChallenges) {
    if (c.expiresAt < now) issuedChallenges.delete(id);
  }
  for (const [t, v] of tokenStore) {
    if (v.expiresAt < now) tokenStore.delete(t);
  }
}
setInterval(cleanup, 30_000).unref?.();

function issueChallenge(ip) {
  const salt = crypto.randomBytes(8).toString('hex');
  const target = '0000'; // 4 hex zero prefix
  const id = uuid();
  const expiresAt = Date.now() + config.challenge.ttl * 1000;
  issuedChallenges.set(id, { ip, salt, target, expiresAt });
  return { id, salt, target, expiresAt, algorithm: 'sha256-pow-v1' };
}

function verifyChallenge({ id, nonce, signals }, ip) {
  const c = issuedChallenges.get(id);
  if (!c) return { ok: false, reason: 'challenge_unknown_or_expired' };
  if (c.ip !== ip) return { ok: false, reason: 'ip_mismatch' };
  if (c.expiresAt < Date.now()) {
    issuedChallenges.delete(id);
    return { ok: false, reason: 'expired' };
  }

  const digest = crypto.createHash('sha256').update(c.salt + nonce).digest('hex');
  if (!digest.startsWith(c.target)) {
    return { ok: false, reason: 'pow_invalid' };
  }

  // Behavioural plausibility checks. A bot typically has:
  //  - 0 mouse moves
  //  - same screen.width every time
  //  - timezone "UTC" or empty
  // We don't enforce any single signal; we score them.
  const sig = signals || {};
  let plausibility = 0;
  if (typeof sig.mouseMoves === 'number' && sig.mouseMoves > 2) plausibility += 0.3;
  if (sig.screen && sig.screen.width && sig.screen.height) plausibility += 0.2;
  if (sig.timezone && sig.timezone !== 'UTC') plausibility += 0.2;
  if (typeof sig.solveMs === 'number' && sig.solveMs > 30 && sig.solveMs < 30_000) plausibility += 0.3;

  if (plausibility < 0.3) {
    return { ok: false, reason: 'low_behavioural_plausibility', plausibility };
  }

  // Mint token
  const token = crypto
    .createHmac('sha256', config.challenge.secret)
    .update(`${ip}:${id}:${Date.now()}`)
    .digest('hex');

  tokenStore.set(token, { ip, expiresAt: Date.now() + config.challenge.ttl * 1000 });
  issuedChallenges.delete(id);

  return { ok: true, token, plausibility };
}

function verifyToken(token, ip) {
  if (!token) return false;
  const v = tokenStore.get(token);
  if (!v) return false;
  if (v.ip !== ip) return false;
  if (v.expiresAt < Date.now()) {
    tokenStore.delete(token);
    return false;
  }
  return true;
}

function stats() {
  return {
    pendingChallenges: issuedChallenges.size,
    activeTokens: tokenStore.size,
  };
}

module.exports = { issueChallenge, verifyChallenge, verifyToken, stats };
