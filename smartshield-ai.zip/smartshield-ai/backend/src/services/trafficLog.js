/**
 * trafficLog
 *
 * Two-tier logging:
 *   1. In-memory ring buffer (fast, drives WebSocket dashboard updates)
 *   2. Mongo persistence (best-effort, async — survives restarts)
 *
 * Also maintains rolling counters used by /api/metrics.
 */

const RingBuffer = require('../utils/ringBuffer');
const TrafficEvent = require('../models/TrafficEvent');
const logger = require('../utils/logger');

const events = new RingBuffer(1000);
const lastNSeconds = []; // [{ts, allowed, blocked, challenged, score}]

function rollWindow() {
  const cutoff = Date.now() - 5 * 60_000; // keep 5 minutes
  while (lastNSeconds.length && lastNSeconds[0].ts < cutoff) lastNSeconds.shift();
}

function record(ctx) {
  const event = {
    requestId: ctx.requestId,
    ts: ctx.receivedAt,
    ip: ctx.ip,
    country: ctx.country,
    method: ctx.method,
    path: ctx.path,
    ua: ctx.ua,
    score: ctx.score,
    classification: ctx.classification,
    action: ctx.action,
    bypass: ctx.bypass,
    modelSource: ctx.modelSource,
    modelConfidence: ctx.modelConfidence,
    features: ctx.features,
  };
  events.push(event);
  lastNSeconds.push({
    ts: event.ts,
    action: event.action,
    score: event.score,
    classification: event.classification,
    country: event.country?.code,
  });
  rollWindow();

  // Async persistence — never block the request path
  TrafficEvent.create(event).catch((err) => {
    logger.debug('Mongo write failed (non-fatal)', { err: err.message });
  });
  return event;
}

function recent(n = 100) {
  return events.recent(n);
}

function metrics(windowMs = 60_000) {
  const cutoff = Date.now() - windowMs;
  const recent = lastNSeconds.filter((e) => e.ts >= cutoff);
  const total = recent.length;
  const allowed = recent.filter((e) => e.action === 'allow').length;
  const blocked = recent.filter((e) => e.action === 'block').length;
  const challenged = recent.filter((e) => e.action === 'challenge').length;
  const human = recent.filter((e) => e.classification === 'human').length;
  const bot = recent.filter((e) => e.classification === 'bot').length;
  const suspicious = recent.filter((e) => e.classification === 'suspicious').length;
  const avgScore = total ? recent.reduce((s, e) => s + (e.score || 0), 0) / total : 0;
  const byCountry = recent.reduce((acc, e) => {
    const k = e.country || 'XX';
    acc[k] = (acc[k] || 0) + 1;
    return acc;
  }, {});
  return {
    windowMs,
    total,
    rps: total / (windowMs / 1000),
    allowed,
    blocked,
    challenged,
    human,
    bot,
    suspicious,
    avgScore,
    byCountry,
    blockRate: total ? blocked / total : 0,
    botRate: total ? bot / total : 0,
  };
}

function timeseries(bucketMs = 1000, durationMs = 120_000) {
  const cutoff = Date.now() - durationMs;
  const buckets = new Map();
  for (const e of lastNSeconds) {
    if (e.ts < cutoff) continue;
    const b = Math.floor(e.ts / bucketMs) * bucketMs;
    if (!buckets.has(b)) buckets.set(b, { ts: b, total: 0, blocked: 0, challenged: 0, allowed: 0, scoreSum: 0 });
    const bk = buckets.get(b);
    bk.total += 1;
    bk.scoreSum += e.score || 0;
    if (e.action === 'block') bk.blocked += 1;
    else if (e.action === 'challenge') bk.challenged += 1;
    else bk.allowed += 1;
  }
  return [...buckets.values()]
    .sort((a, b) => a.ts - b.ts)
    .map((b) => ({ ...b, avgScore: b.total ? b.scoreSum / b.total : 0 }));
}

module.exports = { record, recent, metrics, timeseries };
