/**
 * cpuMetrics
 *
 * Samples Node process CPU + memory at a fixed interval and exposes both
 * the latest sample and a rolling timeseries. The dashboard renders this
 * as the "system load" graph during the attack/mitigation demo.
 *
 * On Linux/Mac this is real process CPU usage. On Windows we approximate
 * via os.loadavg() fallback when needed.
 */

const os = require('os');

const samples = [];
const MAX_SAMPLES = 240; // ~4 minutes at 1Hz

let lastCpu = process.cpuUsage();
let lastTs = Date.now();

function sample() {
  const now = Date.now();
  const u = process.cpuUsage(lastCpu);
  const elapsedMicros = (now - lastTs) * 1000;
  const cpuPct = elapsedMicros > 0 ? Math.min(100, ((u.user + u.system) / elapsedMicros) * 100) : 0;
  const mem = process.memoryUsage();
  const sample = {
    ts: now,
    cpu: Number(cpuPct.toFixed(2)),
    rssMb: Number((mem.rss / 1024 / 1024).toFixed(1)),
    heapMb: Number((mem.heapUsed / 1024 / 1024).toFixed(1)),
    load1: os.loadavg()[0] || 0,
  };
  samples.push(sample);
  if (samples.length > MAX_SAMPLES) samples.shift();
  lastCpu = process.cpuUsage();
  lastTs = now;
  return sample;
}

setInterval(sample, 1000).unref?.();

function latest() {
  return samples[samples.length - 1] || sample();
}

function series() {
  return [...samples];
}

module.exports = { latest, series, sample };
