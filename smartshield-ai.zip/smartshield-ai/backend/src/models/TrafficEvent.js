const mongoose = require('mongoose');

const TrafficEventSchema = new mongoose.Schema(
  {
    requestId: { type: String, index: true },
    ts: { type: Number, index: true },
    ip: { type: String, index: true },
    country: {
      code: String,
      name: String,
      lat: Number,
      lng: Number,
    },
    method: String,
    path: String,
    ua: String,
    score: Number,
    classification: { type: String, index: true },
    action: { type: String, index: true },
    bypass: String,
    modelSource: String,
    modelConfidence: Number,
    features: mongoose.Schema.Types.Mixed,
  },
  { timestamps: true, collection: 'traffic_events' }
);

TrafficEventSchema.index({ ts: -1 });
TrafficEventSchema.index({ 'country.code': 1, ts: -1 });

module.exports = mongoose.models.TrafficEvent || mongoose.model('TrafficEvent', TrafficEventSchema);
