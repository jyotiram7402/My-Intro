const mongoose = require('mongoose');

const SuspiciousIpSchema = new mongoose.Schema(
  {
    ip: { type: String, unique: true, index: true },
    country: { code: String, name: String },
    firstSeen: Number,
    lastSeen: Number,
    blockCount: { type: Number, default: 0 },
    challengeCount: { type: Number, default: 0 },
    avgScore: Number,
    notes: String,
  },
  { timestamps: true, collection: 'suspicious_ips' }
);

module.exports = mongoose.models.SuspiciousIp || mongoose.model('SuspiciousIp', SuspiciousIpSchema);
