/**
 * Centralized configuration. All env access flows through this module so
 * the rest of the codebase never reads process.env directly.
 */

const num = (v, d) => (v === undefined || v === '' ? d : Number(v));
const bool = (v, d) => (v === undefined ? d : String(v).toLowerCase() === 'true');

const config = {
  env: process.env.NODE_ENV || 'development',
  port: num(process.env.PORT, 5000),

  frontendOrigin: process.env.FRONTEND_ORIGIN || 'http://localhost:3000',
  dummySiteUrl: process.env.DUMMY_SITE_URL || 'http://localhost:4000',
  aiEngineUrl: process.env.AI_ENGINE_URL || 'http://localhost:8000',

  mongoUri: process.env.MONGO_URI || 'mongodb://localhost:27017/smartshield',

  shield: {
    enabled: bool(process.env.SHIELD_ENABLED, true),
    blockThreshold: num(process.env.RISK_BLOCK_THRESHOLD, 0.85),
    challengeThreshold: num(process.env.RISK_CHALLENGE_THRESHOLD, 0.55),
  },

  challenge: {
    secret: process.env.CHALLENGE_SECRET || 'dev-secret-change-me',
    ttl: num(process.env.CHALLENGE_TOKEN_TTL_SECONDS, 600),
  },

  rateLimit: {
    globalRpm: num(process.env.GLOBAL_RPM, 600),
    perIpRpm: num(process.env.PER_IP_RPM, 120),
  },

  metrics: {
    windowMs: num(process.env.METRICS_WINDOW_MS, 2000),
  },
};

module.exports = config;
