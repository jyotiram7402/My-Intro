const mongoose = require('mongoose');
const config = require('./index');
const logger = require('../utils/logger');

async function connectMongo() {
  if (!config.mongoUri) {
    logger.warn('MONGO_URI not set — running in in-memory mode (logs not persisted)');
    return;
  }
  try {
    await mongoose.connect(config.mongoUri, {
      autoIndex: true,
      serverSelectionTimeoutMS: 5000,
    });
    logger.info('Connected to MongoDB');
  } catch (err) {
    logger.error('MongoDB connection failed — continuing without persistence', {
      err: err.message,
    });
  }
}

module.exports = { connectMongo };
