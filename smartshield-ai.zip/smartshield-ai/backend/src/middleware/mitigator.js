/**
 * mitigator
 *
 * Translates an AI risk score into one of three actions:
 *   - allow:     forward to upstream as normal
 *   - challenge: respond with a JS challenge page; valid completion
 *                yields a token that bypasses re-scoring for TTL
 *   - block:     short-circuit with 403 and log
 *
 * Thresholds are configurable so researchers can sweep them and study
 * precision/recall trade-offs.
 */

const config = require('../config');
const trafficLog = require('../services/trafficLog');
const shieldState = require('../services/shieldState');
const challengeService = require('../services/challengeService');
const broadcaster = require('../socket/broadcaster');

function pickAction(score) {
  if (!shieldState.isEnabled()) return 'allow';
  if (score >= config.shield.blockThreshold) return 'block';
  if (score >= config.shield.challengeThreshold) return 'challenge';
  return 'allow';
}

module.exports = async function mitigator(req, res, next) {
  const ctx = req.smartshield;
  if (!ctx) return next();

  // If client already solved a challenge in this session, trust the token.
  if (ctx.features.challenge_solved) {
    const token = req.headers['x-shield-token'];
    if (challengeService.verifyToken(token, ctx.ip)) {
      ctx.action = 'allow';
      ctx.bypass = 'valid-token';
      await persist(ctx);
      return next();
    }
  }

  const action = pickAction(ctx.score);
  ctx.action = action;

  if (action === 'block') {
    await persist(ctx);
    return res.status(403).json({
      error: 'BlockedByShield',
      message: 'Your request has been blocked by SmartShield AI.',
      requestId: ctx.requestId,
      score: ctx.score,
    });
  }

  if (action === 'challenge') {
    const challenge = challengeService.issueChallenge(ctx.ip);
    ctx.challengeId = challenge.id;
    await persist(ctx);
    return res.status(202).json({
      action: 'challenge',
      challenge,
      message: 'Please solve the SmartShield challenge to continue.',
      requestId: ctx.requestId,
    });
  }

  // allow
  await persist(ctx);
  next();
};

async function persist(ctx) {
  try {
    const event = trafficLog.record(ctx);
    broadcaster.emitTraffic(event);
  } catch (e) {
    // best-effort — don't break the request path
  }
}
