/**
 * aiScorer
 *
 * Calls the Python AI engine to obtain a risk score for the current
 * request. Falls back to a fast, deterministic heuristic if the engine
 * is unreachable so the dashboard demo never stalls.
 */

const axios = require('axios');
const config = require('../config');
const logger = require('../utils/logger');
const shieldState = require('../services/shieldState');

const aiClient = axios.create({
  baseURL: config.aiEngineUrl,
  timeout: 800,
});

function heuristicScore(features) {
  let score = 0;
  if (features.ua_class === 'bot-known') score += 0.6;
  else if (features.ua_class === 'bot-suspect') score += 0.35;
  else if (features.ua_class === 'unknown') score += 0.2;
  score += Math.min(0.4, features.request_rate_per_min / 200);
  score += features.header_anomaly_score * 0.3;
  if (!features.has_cookie) score += 0.05;
  if (!features.accept_lang_count) score += 0.05;
  return Math.max(0, Math.min(1, score));
}

module.exports = async function aiScorer(req, _res, next) {
  const ctx = req.smartshield;
  if (!ctx) return next();

  // If shield is disabled globally, skip scoring entirely (open mode).
  if (!shieldState.isEnabled()) {
    ctx.score = 0;
    ctx.classification = 'unscored';
    ctx.modelSource = 'disabled';
    return next();
  }

  try {
    const { data } = await aiClient.post('/predict', {
      request_id: ctx.requestId,
      features: ctx.features,
      ip: ctx.ip,
      ua: ctx.ua,
      path: ctx.path,
      method: ctx.method,
    });
    ctx.score = Number(data.score);
    ctx.classification = data.classification;
    ctx.modelSource = data.model || 'ensemble';
    ctx.modelConfidence = data.confidence || data.score;
    ctx.featureContributions = data.contributions || null;
  } catch (err) {
    logger.warn('AI engine unreachable — using heuristic fallback', {
      err: err.message,
    });
    const score = heuristicScore(ctx.features);
    ctx.score = score;
    ctx.modelSource = 'heuristic-fallback';
    ctx.modelConfidence = score;
    ctx.classification = score > 0.7 ? 'bot' : score > 0.45 ? 'suspicious' : 'human';
  }
  next();
};
