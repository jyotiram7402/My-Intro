/**
 * featureExtractor
 *
 * Builds a behavioural feature vector for every request. These features
 * feed both the AI engine (via aiScorer) and the analytics pipeline.
 *
 * Features captured:
 *  - request_rate: requests/minute from this client (sliding window)
 *  - session_age_ms
 *  - header_anomaly_score: heuristic 0..1 based on missing/odd headers
 *  - ua_class: human|bot-known|bot-suspect|unknown
 *  - has_cookie: bool
 *  - accept_lang_count
 *  - referrer_present
 *  - method_class
 *  - challenge_solved: bool (set by /api/challenge/verify earlier)
 */

const UAParser = require('ua-parser-js');
const geo = require('../utils/geo');

const KNOWN_BOT_UA_RE = /(bot|spider|crawl|wget|curl|python-requests|axios|httpclient|scrapy|phantomjs|headless)/i;
const SUSPECT_UA_RE = /(java\/|libwww|go-http-client|okhttp|requests)/i;

const sessionsByIp = new Map();
const SESSION_TTL_MS = 5 * 60_000;

function classifyUserAgent(ua) {
  if (!ua) return 'unknown';
  if (KNOWN_BOT_UA_RE.test(ua)) return 'bot-known';
  if (SUSPECT_UA_RE.test(ua)) return 'bot-suspect';
  const parsed = new UAParser(ua).getResult();
  if (!parsed.browser.name && !parsed.engine.name) return 'bot-suspect';
  return 'human';
}

function headerAnomalyScore(req) {
  let score = 0;
  if (!req.headers['user-agent']) score += 0.4;
  if (!req.headers['accept']) score += 0.2;
  if (!req.headers['accept-language']) score += 0.15;
  if (!req.headers['accept-encoding']) score += 0.1;
  if (!req.headers['referer'] && req.method === 'POST') score += 0.05;
  // Implausible combinations: e.g. browser-like UA but no accept-language
  if (req.headers['user-agent'] && /Mozilla/i.test(req.headers['user-agent']) && !req.headers['accept-language']) {
    score += 0.1;
  }
  return Math.min(1, score);
}

function trackSession(ip) {
  const now = Date.now();
  let s = sessionsByIp.get(ip);
  if (!s || now - s.lastSeen > SESSION_TTL_MS) {
    s = { firstSeen: now, lastSeen: now, count: 0, timestamps: [] };
    sessionsByIp.set(ip, s);
  }
  s.count += 1;
  s.lastSeen = now;
  s.timestamps.push(now);
  // keep a 60s window
  while (s.timestamps.length && now - s.timestamps[0] > 60_000) s.timestamps.shift();
  return s;
}

module.exports = function featureExtractor(req, _res, next) {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const ua = req.headers['user-agent'] || '';
  const session = trackSession(ip);
  const country = geo.lookup(ip);

  req.smartshield = {
    requestId: req.id,
    ip,
    country,
    ua,
    method: req.method,
    path: req.path,
    referrer: req.headers['referer'] || null,
    receivedAt: Date.now(),
    features: {
      request_rate_per_min: session.timestamps.length,
      session_age_ms: Date.now() - session.firstSeen,
      header_anomaly_score: headerAnomalyScore(req),
      ua_class: classifyUserAgent(ua),
      has_cookie: !!req.headers['cookie'],
      accept_lang_count: (req.headers['accept-language'] || '').split(',').filter(Boolean).length,
      referrer_present: !!req.headers['referer'],
      method_class: req.method === 'GET' ? 'safe' : 'mutating',
      challenge_solved: !!req.headers['x-shield-token'],
      content_length: Number(req.headers['content-length'] || 0),
    },
  };
  next();
};
