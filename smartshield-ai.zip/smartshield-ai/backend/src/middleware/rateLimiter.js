/**
 * Simple per-IP token bucket rate limiter. Coarse first-line defence
 * placed before the AI scorer so the engine isn't overwhelmed during
 * floods. The fine-grained mitigation happens after AI scoring.
 */

const config = require('../config');

const buckets = new Map();
const REFILL_MS = 60_000;

function getBucket(ip) {
  const now = Date.now();
  let b = buckets.get(ip);
  if (!b) {
    b = { tokens: config.rateLimit.perIpRpm, refilledAt: now };
    buckets.set(ip, b);
  }
  const elapsed = now - b.refilledAt;
  if (elapsed >= REFILL_MS) {
    b.tokens = config.rateLimit.perIpRpm;
    b.refilledAt = now;
  }
  return b;
}

module.exports = function rateLimiter(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress || 'unknown';
  const b = getBucket(ip);
  if (b.tokens <= 0) {
    return res.status(429).json({
      error: 'RateLimited',
      message: 'Too many requests from this IP — slow down.',
    });
  }
  b.tokens -= 1;
  next();
};
