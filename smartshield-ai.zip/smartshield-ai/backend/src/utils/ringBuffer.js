/**
 * Tiny ring buffer used to retain the last N events in memory for
 * dashboard streaming without unbounded growth.
 */
class RingBuffer {
  constructor(capacity = 500) {
    this.capacity = capacity;
    this.items = [];
  }
  push(item) {
    this.items.push(item);
    if (this.items.length > this.capacity) this.items.shift();
    return item;
  }
  recent(n = 50) {
    return this.items.slice(-n);
  }
  toArray() {
    return [...this.items];
  }
  clear() {
    this.items = [];
  }
  get length() {
    return this.items.length;
  }
}

module.exports = RingBuffer;
