/**
 * Lightweight, deterministic IP -> country mapper for demo / research use.
 *
 * For production, replace this with MaxMind GeoLite2 or ip-api.com lookups.
 * This module intentionally has zero network dependencies so the dashboard
 * can render country-wise visualizations even without a GeoIP database.
 */

const COUNTRIES = [
  { code: 'CN', name: 'China', lat: 35.86, lng: 104.19 },
  { code: 'RU', name: 'Russia', lat: 61.52, lng: 105.31 },
  { code: 'US', name: 'United States', lat: 37.09, lng: -95.71 },
  { code: 'IN', name: 'India', lat: 20.59, lng: 78.96 },
  { code: 'BR', name: 'Brazil', lat: -14.23, lng: -51.92 },
  { code: 'DE', name: 'Germany', lat: 51.16, lng: 10.45 },
  { code: 'GB', name: 'United Kingdom', lat: 55.37, lng: -3.43 },
  { code: 'FR', name: 'France', lat: 46.22, lng: 2.21 },
  { code: 'JP', name: 'Japan', lat: 36.20, lng: 138.25 },
  { code: 'KR', name: 'South Korea', lat: 35.90, lng: 127.76 },
  { code: 'NG', name: 'Nigeria', lat: 9.08, lng: 8.67 },
  { code: 'IR', name: 'Iran', lat: 32.42, lng: 53.68 },
];

function hashIp(ip) {
  let h = 0;
  for (let i = 0; i < ip.length; i++) h = (h * 31 + ip.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function lookup(ip) {
  if (!ip) return COUNTRIES[2]; // default US
  const idx = hashIp(ip) % COUNTRIES.length;
  return COUNTRIES[idx];
}

module.exports = { lookup, COUNTRIES };
