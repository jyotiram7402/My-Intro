const router = require('express').Router();
const challengeService = require('../services/challengeService');

router.post('/issue', (req, res) => {
  const ip = req.ip;
  const challenge = challengeService.issueChallenge(ip);
  res.json(challenge);
});

router.post('/verify', (req, res) => {
  const ip = req.ip;
  const result = challengeService.verifyChallenge(req.body || {}, ip);
  if (!result.ok) return res.status(400).json(result);
  res.json(result);
});

router.get('/page', (_req, res) => {
  // Standalone challenge HTML page that the gateway can return inline
  // when an upstream needs to redirect a flagged client.
  res.setHeader('content-type', 'text/html');
  res.send(`<!doctype html>
<html><head><meta charset="utf-8"/><title>SmartShield Verification</title>
<style>body{font-family:system-ui;background:#0b1020;color:#e5edff;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
.box{background:rgba(255,255,255,.06);backdrop-filter:blur(20px);padding:32px;border-radius:18px;max-width:420px;text-align:center;border:1px solid rgba(120,200,255,.2)}
.spinner{width:48px;height:48px;border:4px solid rgba(120,200,255,.2);border-top-color:#5cf;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 16px}
@keyframes spin{to{transform:rotate(360deg)}}
h1{font-size:20px;margin:0 0 8px}p{opacity:.75;font-size:14px}
</style></head>
<body><div class="box"><div class="spinner"></div>
<h1>Verifying your browser</h1><p>SmartShield AI is checking that you're human. This takes a moment.</p>
<p id="s" style="font-size:12px;opacity:.5;margin-top:16px">Solving challenge…</p></div>
<script>(${challengeClientScript.toString()})()</script>
</body></html>`);
});

// Inline challenge solver (kept here so the HTML page is fully self-contained)
function challengeClientScript() {
  async function run() {
    const sEl = document.getElementById('s');
    try {
      const r = await fetch('/api/challenge/issue', { method: 'POST' });
      const c = await r.json();
      const start = Date.now();
      let nonce = 0;
      while (true) {
        nonce++;
        const buf = new TextEncoder().encode(c.salt + nonce);
        const hashBuf = await crypto.subtle.digest('SHA-256', buf);
        const hex = Array.from(new Uint8Array(hashBuf))
          .map((b) => b.toString(16).padStart(2, '0'))
          .join('');
        if (hex.startsWith(c.target)) break;
      }
      const solveMs = Date.now() - start;
      const verify = await fetch('/api/challenge/verify', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          id: c.id,
          nonce,
          signals: {
            mouseMoves: window.__mm || 0,
            screen: { width: screen.width, height: screen.height },
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            solveMs,
          },
        }),
      });
      const v = await verify.json();
      if (v.ok) {
        sEl.textContent = 'Verified. Redirecting…';
        document.cookie = `shield_token=${v.token}; path=/; max-age=600`;
        setTimeout(() => (location.href = '/'), 600);
      } else {
        sEl.textContent = 'Verification failed.';
      }
    } catch (e) {
      sEl.textContent = 'Verification error: ' + e.message;
    }
  }
  window.__mm = 0;
  document.addEventListener('mousemove', () => (window.__mm += 1));
  run();
}

module.exports = router;
