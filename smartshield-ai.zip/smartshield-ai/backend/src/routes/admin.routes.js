const router = require('express').Router();
const shieldState = require('../services/shieldState');
const broadcaster = require('../socket/broadcaster');
const challengeService = require('../services/challengeService');

// GET current shield state
router.get('/state', (_req, res) => {
  res.json({ ...shieldState.snapshot(), challenge: challengeService.stats() });
});

// PATCH toggle / thresholds
router.patch('/state', (req, res) => {
  const { enabled, blockThreshold, challengeThreshold } = req.body || {};
  if (typeof enabled === 'boolean') shieldState.setEnabled(enabled);
  if (typeof blockThreshold === 'number' || typeof challengeThreshold === 'number') {
    shieldState.setThresholds({ block: blockThreshold, challenge: challengeThreshold });
  }
  const snap = shieldState.snapshot();
  broadcaster.emitShieldChange(snap);
  broadcaster.emitAlert({
    level: snap.enabled ? 'info' : 'warn',
    title: snap.enabled ? 'Shield enabled' : 'Shield disabled',
    ts: Date.now(),
  });
  res.json(snap);
});

module.exports = router;
