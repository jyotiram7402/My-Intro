/**
 * proxy.routes
 *
 * Final stage of the pipeline. By the time we get here, the request
 * has been: rate-limited → feature-extracted → AI-scored → mitigated.
 * If `req.smartshield.action === 'allow'`, we forward to the dummy
 * vulnerable website and stream the response back.
 */

const router = require('express').Router();
const { createProxyMiddleware } = require('http-proxy-middleware');
const config = require('../config');

const proxy = createProxyMiddleware({
  target: config.dummySiteUrl,
  changeOrigin: true,
  pathRewrite: (path) => path.replace(/^\/proxy/, ''),
  selfHandleResponse: false,
  on: {
    proxyReq(proxyReq, req) {
      const ctx = req.smartshield;
      if (!ctx) return;
      proxyReq.setHeader('x-shield-score', String(ctx.score ?? 0));
      proxyReq.setHeader('x-shield-class', ctx.classification || 'unknown');
      proxyReq.setHeader('x-shield-action', ctx.action || 'allow');
      proxyReq.setHeader('x-shield-id', ctx.requestId || '');
    },
  },
});

router.use('/', proxy);

module.exports = router;
