const router = require('express').Router();
const trafficLog = require('../services/trafficLog');
const cpuMetrics = require('../services/cpuMetrics');
const TrafficEvent = require('../models/TrafficEvent');

router.get('/summary', (_req, res) => {
  res.json({
    metrics: trafficLog.metrics(),
    cpu: cpuMetrics.latest(),
  });
});

router.get('/timeseries', (req, res) => {
  const bucketMs = Number(req.query.bucket) || 1000;
  const durationMs = Number(req.query.window) || 120_000;
  res.json({
    traffic: trafficLog.timeseries(bucketMs, durationMs),
    cpu: cpuMetrics.series(),
  });
});

router.get('/recent', (req, res) => {
  const n = Math.min(500, Number(req.query.n) || 100);
  res.json(trafficLog.recent(n));
});

router.get('/history', async (req, res) => {
  const limit = Math.min(500, Number(req.query.limit) || 100);
  try {
    const docs = await TrafficEvent.find().sort({ ts: -1 }).limit(limit).lean();
    res.json(docs);
  } catch (err) {
    res.status(503).json({ error: 'history_unavailable', message: err.message });
  }
});

router.get('/countries', (_req, res) => {
  const m = trafficLog.metrics(60_000);
  res.json(m.byCountry);
});

module.exports = router;
