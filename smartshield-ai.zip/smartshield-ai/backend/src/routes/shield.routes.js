/**
 * Operator endpoints used by the dashboard's "simulator" page —
 * triggers the bot attack simulator over HTTP if the user prefers
 * not to spawn the script manually.
 */

const router = require('express').Router();
const axios = require('axios');
const config = require('../config');
const broadcaster = require('../socket/broadcaster');
const logger = require('../utils/logger');

let activeAttack = null;

router.post('/simulate/start', async (req, res) => {
  const { mode = 'bot', concurrency = 25, durationSec = 30, targetPath = '/' } = req.body || {};
  if (activeAttack) return res.status(409).json({ error: 'attack_already_running' });

  activeAttack = { mode, concurrency, startedAt: Date.now(), durationSec };
  broadcaster.emitAlert({
    level: 'warn',
    title: `${mode === 'bot' ? 'Simulated bot attack' : 'Traffic burst'} started`,
    detail: `concurrency=${concurrency}, duration=${durationSec}s`,
    ts: Date.now(),
  });

  const stopAt = Date.now() + durationSec * 1000;
  const fakeIps = generateFakeIps(concurrency);
  const userAgents = mode === 'bot' ? BOT_UAS : HUMAN_UAS;

  // Fire-and-forget background traffic generator
  (async () => {
    while (Date.now() < stopAt && activeAttack) {
      const tasks = [];
      for (let i = 0; i < concurrency; i++) {
        const ua = userAgents[i % userAgents.length];
        const ip = fakeIps[i % fakeIps.length];
        tasks.push(
          axios
            .get(`http://localhost:${config.port}/proxy${targetPath}`, {
              headers: {
                'user-agent': ua,
                'x-forwarded-for': ip,
                'accept': mode === 'bot' ? '*/*' : 'text/html,application/xhtml+xml',
              },
              timeout: 1500,
              validateStatus: () => true,
            })
            .catch(() => null)
        );
      }
      await Promise.all(tasks);
      await new Promise((r) => setTimeout(r, 200));
    }
    activeAttack = null;
    broadcaster.emitAlert({
      level: 'info',
      title: 'Simulated attack ended',
      ts: Date.now(),
    });
  })().catch((err) => logger.error('simulator error', { err: err.message }));

  res.json({ ok: true, attack: activeAttack });
});

router.post('/simulate/stop', (_req, res) => {
  activeAttack = null;
  broadcaster.emitAlert({ level: 'info', title: 'Simulated attack stopped (manual)', ts: Date.now() });
  res.json({ ok: true });
});

router.get('/simulate/status', (_req, res) => res.json({ active: !!activeAttack, attack: activeAttack }));

function generateFakeIps(n) {
  const ips = [];
  for (let i = 0; i < n; i++) {
    ips.push(`${rand(1, 223)}.${rand(0, 255)}.${rand(0, 255)}.${rand(1, 254)}`);
  }
  return ips;
}
function rand(a, b) {
  return Math.floor(a + Math.random() * (b - a));
}

const BOT_UAS = [
  'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',
  'python-requests/2.31.0',
  'curl/8.4.0',
  'Go-http-client/1.1',
  'okhttp/4.12.0',
  'Mozilla/5.0 (compatible; SemrushBot/7~bl; +http://www.semrush.com/bot.html)',
  'Java/17.0.5',
];
const HUMAN_UAS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
  'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0',
];

module.exports = router;
