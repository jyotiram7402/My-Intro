/**
 * Tiny pub-sub helper so non-socket modules (middleware, services) can
 * emit to the dashboard without holding a reference to the io instance.
 */
let io = null;

module.exports = {
  bind(ioInstance) {
    io = ioInstance;
  },
  emitTraffic(event) {
    if (!io) return;
    io.to('dashboard').emit('traffic', event);
  },
  emitAlert(alert) {
    if (!io) return;
    io.to('dashboard').emit('alert', alert);
  },
  emitShieldChange(state) {
    if (!io) return;
    io.to('dashboard').emit('shield', state);
  },
};
