/**
 * Socket.IO setup. The dashboard subscribes to the `dashboard` room and
 * receives streaming traffic + cpu samples. Rate of events is naturally
 * bounded by the gateway.
 */

const broadcaster = require('./broadcaster');
const cpuMetrics = require('../services/cpuMetrics');
const trafficLog = require('../services/trafficLog');
const shieldState = require('../services/shieldState');
const logger = require('../utils/logger');

function attachSocket(io) {
  broadcaster.bind(io);

  io.on('connection', (socket) => {
    logger.info('dashboard connected', { sid: socket.id });
    socket.join('dashboard');

    socket.emit('hello', {
      shield: shieldState.snapshot(),
      cpu: cpuMetrics.latest(),
      metrics: trafficLog.metrics(),
    });

    socket.on('disconnect', () => logger.info('dashboard disconnected', { sid: socket.id }));
  });

  // Periodic system-wide broadcasts
  setInterval(() => {
    io.to('dashboard').emit('cpu', cpuMetrics.latest());
    io.to('dashboard').emit('metrics', trafficLog.metrics());
  }, 1000).unref?.();
}

module.exports = { attachSocket };
