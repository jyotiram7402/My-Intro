/**
 * SmartShield AI - Gateway Server (entrypoint)
 *
 * Boots the Express HTTP server, attaches Socket.IO, connects to MongoDB,
 * and wires up the request pipeline:
 *
 *    incoming HTTP request
 *        |
 *        v
 *    [ rate limiter ] -> [ feature extractor ] -> [ AI scorer ] -> [ mitigator ]
 *        |                                                              |
 *        |                                                              +--> block / challenge / allow
 *        |
 *        +-> proxy to dummy website (allowed) or serve challenge page
 *
 * The pipeline is designed so each stage can be swapped or disabled
 * independently for research / ablation experiments.
 */

require('dotenv').config();

const http = require('http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const { Server } = require('socket.io');

const config = require('./src/config');
const logger = require('./src/utils/logger');
const { connectMongo } = require('./src/config/db');
const { attachSocket } = require('./src/socket');

const shieldRoutes = require('./src/routes/shield.routes');
const challengeRoutes = require('./src/routes/challenge.routes');
const metricsRoutes = require('./src/routes/metrics.routes');
const adminRoutes = require('./src/routes/admin.routes');
const proxyRoutes = require('./src/routes/proxy.routes');

const requestId = require('./src/middleware/requestId');
const featureExtractor = require('./src/middleware/featureExtractor');
const aiScorer = require('./src/middleware/aiScorer');
const mitigator = require('./src/middleware/mitigator');
const rateLimiter = require('./src/middleware/rateLimiter');

async function bootstrap() {
  const app = express();
  const server = http.createServer(app);

  const io = new Server(server, {
    cors: { origin: config.frontendOrigin, credentials: true },
  });
  attachSocket(io);

  // ---- Core middleware ----
  app.use(
    helmet({
      contentSecurityPolicy: false, // disabled for dashboard iframe demo
    })
  );
  app.use(cors({ origin: config.frontendOrigin, credentials: true }));
  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true }));
  app.use(morgan('tiny', { stream: { write: (msg) => logger.http(msg.trim()) } }));
  app.use(requestId);

  // ---- Health ----
  app.get('/healthz', (_req, res) => res.json({ ok: true, service: 'smartshield-gateway' }));

  // ---- Admin / Metrics / Challenge APIs (not subject to mitigation) ----
  app.use('/api/admin', adminRoutes);
  app.use('/api/metrics', metricsRoutes);
  app.use('/api/challenge', challengeRoutes);
  app.use('/api/shield', shieldRoutes);

  // ---- The protected pipeline ----
  // Anything mounted under /proxy goes through the full SmartShield pipeline
  // before being forwarded to the dummy website. This is the production path.
  app.use(
    '/proxy',
    rateLimiter,
    featureExtractor,
    aiScorer,
    mitigator,
    proxyRoutes
  );

  // ---- 404 + error fallback ----
  app.use((req, res) => res.status(404).json({ error: 'Not Found', path: req.originalUrl }));
  app.use((err, _req, res, _next) => {
    logger.error('Unhandled error', { err: err.message, stack: err.stack });
    res.status(500).json({ error: 'Internal Server Error' });
  });

  // ---- Storage ----
  await connectMongo();

  server.listen(config.port, () => {
    logger.info(`SmartShield gateway listening on :${config.port}`);
    logger.info(`Frontend origin allowed: ${config.frontendOrigin}`);
    logger.info(`Dummy site target:       ${config.dummySiteUrl}`);
    logger.info(`AI engine target:        ${config.aiEngineUrl}`);
  });

  const shutdown = (signal) => {
    logger.warn(`${signal} received. Shutting down...`);
    server.close(() => process.exit(0));
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('Fatal boot error', err);
  process.exit(1);
});
