# SmartShield AI

**Adaptive Bot Mitigation & Traffic Intelligence System Using Deep Learning Techniques**

> M.Tech Research Project — AI-Powered Cybersecurity for Small & Medium Businesses

SmartShield AI is a research-grade, full-stack adaptive bot mitigation system that detects malicious automated traffic, allows genuine human users, and visualizes attacks in real time. It is designed as a low-cost alternative to enterprise solutions for small and medium businesses, while demonstrating modern deep-learning approaches to traffic intelligence.

---

## Project Background

This project is inspired by a real-world production incident in which a US-based website was rendered unavailable by a sustained bot-traffic attack originating from multiple regions. Container CPU utilization climbed close to 100%, instances crashed, and the website was offline for several hours.

Enterprise mitigation solutions (such as JS-challenge platforms) are highly effective but financially out of reach for many SMBs. SmartShield AI investigates whether **modern deep-learning techniques** can deliver comparable adaptive protection at a fraction of the cost.

---

## Key Capabilities

- Real-time detection of malicious bot traffic
- Behavioral and statistical traffic intelligence
- Adaptive JS challenge based on AI risk score
- Interactive cybersecurity dashboard with live analytics
- Attack simulator for controlled experimentation
- Pluggable ML pipeline (LSTM, Random Forest, Isolation Forest, Autoencoder)

---

## High-Level Architecture

```
                +---------------------------+
                |    Attack Simulator       |
                |  (Bot + Human Traffic)    |
                +-------------+-------------+
                              |
                              v
+---------------+   +---------+----------+   +-------------------+
|  Real Users   |-->|  Node.js Gateway   |-->|  Dummy Website    |
+---------------+   |   (Express + WS)   |   |  (Vulnerable App) |
                    +---+-------+--------+   +-------------------+
                        |       |
                        |       +--> JS Challenge Verification
                        |
                        v
                +-------+--------+        +------------------+
                | AI Detection   | <----> |   MongoDB Logs   |
                | Engine (Py FA) |        +------------------+
                +-------+--------+
                        |
                        v
                +-------+--------+
                |  Dashboard     |
                |  (Next.js UI)  |
                +----------------+
```

---

## Modules

| # | Module | Path | Stack |
|---|--------|------|-------|
| 1 | Frontend Dashboard | `frontend/` | Next.js + Tailwind + ShadCN + Framer Motion + Recharts |
| 2 | Gateway Server | `backend/` | Node.js + Express + Socket.IO |
| 3 | AI Detection Engine | `ai-engine/` | Python + FastAPI + TF/Sklearn |
| 4 | Dummy Vulnerable Website | `dummy-website/` | Node.js + Express |
| 5 | Bot Attack Simulator | `attack-simulator/` | Node.js + Axios |
| 6 | MongoDB Logging Layer | embedded in `backend/` | MongoDB |
| 7 | JS Challenge System | embedded in `backend/` and `frontend/` | JS + crypto |
| 8 | Documentation | `docs/` | Markdown |

---

## Demonstration Flow

**Scenario 1 — Baseline**
The dummy website runs normally with mixed light traffic. Dashboard shows green metrics.

**Scenario 2 — Attack**
Attack simulator launches aggressive bot traffic. Request rate spikes, CPU utilization climbs, dummy website becomes unstable.

**Scenario 3 — Mitigation**
Operator enables SmartShield AI from the dashboard. The AI engine begins scoring requests, JS challenges are issued to suspicious clients, malicious traffic is blocked, genuine users continue uninterrupted, and the dummy website stabilizes.

---

## Quick Start (Local)

> **Prerequisites:** Node.js 20+, Python 3.11+, MongoDB 6+ (local or Atlas), pnpm or npm.
> All commands below are *manual* — this project intentionally ships without auto-install scripts so you can review and run components individually.

```bash
# 1. Start MongoDB (locally or via Atlas — set connection string in env files)

# 2. AI Engine
cd ai-engine
python -m venv .venv
# activate venv
pip install -r requirements.txt
uvicorn main:app --reload --port 8000

# 3. Backend Gateway
cd backend
npm install
npm run dev   # http://localhost:5000

# 4. Dummy Website
cd dummy-website
npm install
npm start     # http://localhost:4000

# 5. Frontend Dashboard
cd frontend
npm install
npm run dev   # http://localhost:3000

# 6. (Optional) Attack Simulator — controlled from dashboard
cd attack-simulator
npm install
node simulator.js --mode=bot
```

Environment files (`.env.example`) are provided in every module — copy them to `.env` and adjust values.

---

## Research Highlights

- **Behavioral feature extraction:** request frequency, session entropy, header anomaly score, navigation cadence, mouse-event distribution, JS-challenge solve time.
- **Hybrid ensemble:** supervised classifier (Random Forest) + sequence model (LSTM) + anomaly detectors (Isolation Forest, Autoencoder reconstruction error).
- **Adaptive mitigation:** challenge intensity scales with risk score (low → cookie, medium → JS challenge, high → block + log).
- **Educational scope:** all challenge logic is original; we do not replicate any commercial product.

See `docs/RESEARCH.md` for the full thesis-aligned write-up.

---

## Repository Layout

```
smartshield-ai/
├── frontend/           # Next.js dashboard
├── backend/            # Express gateway + WebSocket + Mongo logger
├── ai-engine/          # FastAPI service + ML models + training scripts
├── dummy-website/      # Demo vulnerable site
├── attack-simulator/   # Bot + human traffic generator
├── docs/               # Architecture, API, research notes
└── README.md
```

---

## License

Released for academic and educational use. See `LICENSE` for details.

---

## Author

M.Tech research project, 2026.
