#!/usr/bin/env node
/**
 * SmartShield Attack Simulator
 *
 * Generates traffic against the gateway using one of the strategies in
 * `./strategies`. Each strategy returns the request shape (path, method,
 * headers, body). The runner scales it to N concurrent workers for D
 * seconds and prints a tally at the end.
 *
 * Usage:
 *   node simulator.js --mode=bot       --concurrency=25 --duration=60
 *   node simulator.js --mode=human     --concurrency=5  --duration=60
 *   node simulator.js --mode=flood     --concurrency=80 --duration=20
 *   node simulator.js --mode=mixed     --concurrency=15 --duration=60
 */

const axios = require('axios');
const minimist = require('minimist');
const chalk = require('chalk');

const botStrategy = require('./strategies/bot');
const humanStrategy = require('./strategies/human');
const floodStrategy = require('./strategies/flood');
const mixedStrategy = require('./strategies/mixed');

const STRATEGIES = {
  bot: botStrategy,
  human: humanStrategy,
  flood: floodStrategy,
  mixed: mixedStrategy,
};

async function main() {
  const argv = minimist(process.argv.slice(2), {
    default: {
      target: process.env.TARGET || 'http://localhost:5000/proxy',
      mode: 'bot',
      concurrency: 20,
      duration: 30,
      delay: 0,
    },
  });
  const strategy = STRATEGIES[argv.mode];
  if (!strategy) {
    console.error(`unknown mode: ${argv.mode}. Choose: ${Object.keys(STRATEGIES).join(', ')}`);
    process.exit(1);
  }

  const tally = { sent: 0, ok: 0, blocked: 0, challenged: 0, errored: 0, rateLimited: 0 };
  const stopAt = Date.now() + argv.duration * 1000;

  console.log(chalk.cyan(`SmartShield simulator`));
  console.log(`  target:      ${argv.target}`);
  console.log(`  mode:        ${argv.mode}`);
  console.log(`  concurrency: ${argv.concurrency}`);
  console.log(`  duration:    ${argv.duration}s\n`);

  async function worker(id) {
    while (Date.now() < stopAt) {
      const req = strategy({ id, target: argv.target });
      tally.sent += 1;
      try {
        const res = await axios({
          method: req.method,
          url: argv.target + req.path,
          headers: req.headers,
          data: req.body,
          timeout: 4000,
          validateStatus: () => true,
        });
        if (res.status === 200 || res.status === 201) tally.ok += 1;
        else if (res.status === 202) tally.challenged += 1;
        else if (res.status === 403) tally.blocked += 1;
        else if (res.status === 429) tally.rateLimited += 1;
        else tally.errored += 1;
      } catch (err) {
        tally.errored += 1;
      }
      if (argv.delay) await sleep(argv.delay);
    }
  }

  const workers = Array.from({ length: argv.concurrency }, (_, i) => worker(i));
  const reporter = setInterval(() => render(tally), 1000);
  await Promise.all(workers);
  clearInterval(reporter);
  render(tally);
  console.log('\n' + chalk.green('done.'));
}

function render(t) {
  const line =
    chalk.gray(new Date().toLocaleTimeString()) +
    `  sent=${chalk.bold(t.sent)} ` +
    `ok=${chalk.green(t.ok)} ` +
    `challenged=${chalk.yellow(t.challenged)} ` +
    `blocked=${chalk.red(t.blocked)} ` +
    `429=${chalk.magenta(t.rateLimited)} ` +
    `err=${chalk.gray(t.errored)}`;
  process.stdout.write(`\r${line}`);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
