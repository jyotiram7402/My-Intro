# Attack Simulator

Generate controlled bot / human / mixed traffic against the SmartShield gateway.

## Modes

| mode | description |
|------|-------------|
| `human` | realistic browsing (full headers, low rate) |
| `bot` | scrapers + credential stuffers, naked UAs |
| `flood` | volumetric, single endpoint hammered |
| `mixed` | 60% bot / 30% human / 10% flood |

## Usage

```bash
npm install

# 30 concurrent bot workers for 60 seconds, against the gateway
node simulator.js --mode=bot --concurrency=30 --duration=60

# Direct (bypass) the dummy site to see what raw load looks like
node simulator.js --mode=flood --target=http://localhost:4000 --concurrency=80 --duration=20
```

The dashboard's "Simulator" page can also start the same modes
remotely via `POST /api/shield/simulate/start`.
