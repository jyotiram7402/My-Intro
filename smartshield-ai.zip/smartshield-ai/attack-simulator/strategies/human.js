const { pick, PATHS_BROWSING, HUMAN_UAS } = require('./_common');

/**
 * Realistic human-like browsing: full headers, mostly GETs, low rate.
 */
module.exports = function humanStrategy() {
  return {
    method: 'GET',
    path: pick(PATHS_BROWSING),
    headers: {
      'user-agent': pick(HUMAN_UAS),
      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'accept-language': 'en-US,en;q=0.9',
      'accept-encoding': 'gzip, deflate, br',
      'referer': 'https://www.google.com/',
      'cookie': 'sid=abc123; theme=dark',
      'sec-ch-ua': '"Chromium";v="124", "Not-A.Brand";v="99"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
    },
  };
};
