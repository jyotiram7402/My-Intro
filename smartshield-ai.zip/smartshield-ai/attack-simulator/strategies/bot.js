const { pick, fakeIp, PATHS_SCRAPING, PATHS_ABUSE, BOT_UAS } = require('./_common');

/**
 * Aggressive scraper / credential-stuffer.
 *  - Naked or rotating bot user-agents
 *  - No cookies, no referrer, often missing accept-language
 *  - Hits sensitive paths (.env, /wp-admin, /login)
 *  - Spoofed X-Forwarded-For so the gateway sees varied "client IPs"
 */
module.exports = function botStrategy() {
  const aggressive = Math.random() < 0.4;
  return {
    method: aggressive && Math.random() < 0.5 ? 'POST' : 'GET',
    path: aggressive ? pick(PATHS_ABUSE) : pick(PATHS_SCRAPING),
    headers: {
      'user-agent': pick(BOT_UAS),
      'accept': '*/*',
      'x-forwarded-for': fakeIp(),
    },
    body: aggressive ? { username: 'admin', password: 'admin' + Math.random().toString(36).slice(2, 6) } : undefined,
  };
};
