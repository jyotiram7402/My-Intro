const human = require('./human');
const bot = require('./bot');
const flood = require('./flood');

/**
 * Mixed traffic: 60% bot / 30% human / 10% volumetric flood.
 * Useful for verifying that the AI engine doesn't false-positive on
 * legitimate users while still catching attackers.
 */
module.exports = function mixedStrategy(ctx) {
  const r = Math.random();
  if (r < 0.6) return bot(ctx);
  if (r < 0.9) return human(ctx);
  return flood(ctx);
};
