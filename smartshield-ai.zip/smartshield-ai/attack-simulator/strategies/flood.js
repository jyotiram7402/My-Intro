const { fakeIp, BOT_UAS, pick } = require('./_common');

/**
 * Pure volumetric flood: hammer one path with minimal headers.
 * Designed to drive CPU on the dummy site sky-high.
 */
module.exports = function floodStrategy() {
  return {
    method: 'GET',
    path: '/api/products',
    headers: {
      'user-agent': pick(BOT_UAS),
      'x-forwarded-for': fakeIp(),
    },
  };
};
