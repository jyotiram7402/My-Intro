function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
function fakeIp() {
  return `${rand(1, 223)}.${rand(0, 255)}.${rand(0, 255)}.${rand(1, 254)}`;
}
function rand(a, b) { return Math.floor(a + Math.random() * (b - a)); }

const PATHS_BROWSING = ['/', '/api/products', '/api/product/p1', '/api/product/p2', '/login'];
const PATHS_SCRAPING = ['/api/products', '/api/products', '/api/product/p1', '/api/product/p2', '/api/product/p3', '/api/product/p4', '/api/product/p5'];
const PATHS_ABUSE = ['/login', '/api/cart', '/api/products?q=admin', '/wp-admin', '/.env', '/config.json'];

const HUMAN_UAS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15',
  'Mozilla/5.0 (X11; Linux x86_64; rv:124.0) Gecko/20100101 Firefox/124.0',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1',
];

const BOT_UAS = [
  'python-requests/2.31.0',
  'curl/8.4.0',
  'Go-http-client/1.1',
  'okhttp/4.12.0',
  'Java/17.0.5',
  'Mozilla/5.0 (compatible; AhrefsBot/7.0; +http://ahrefs.com/robot/)',
  'Mozilla/5.0 (compatible; SemrushBot/7~bl)',
  'libwww-perl/6.50',
  'Wget/1.20.3 (linux-gnu)',
  'Scrapy/2.11.0 (+https://scrapy.org)',
];

module.exports = { pick, fakeIp, rand, PATHS_BROWSING, PATHS_SCRAPING, PATHS_ABUSE, HUMAN_UAS, BOT_UAS };
